/**
 * ALPACA CLIENT - Paper Trading Integration
 * All assets, all order types, no limits
 */

import axios from 'axios';

const ALPACA_API = process.env.ALPACA_API || 'https://paper-api.alpaca.markets/v2';
const ALPACA_KEY = process.env.ALPACA_KEY;
const ALPACA_SECRET = process.env.ALPACA_SECRET;

if (!ALPACA_KEY || !ALPACA_SECRET) {
  console.warn('⚠️ Alpaca credentials not set. Paper trading disabled.');
}

// ============================================================================
// ALPACA CLIENT
// ============================================================================

export class AlpacaClient {
  private apiKey = ALPACA_KEY;
  private apiSecret = ALPACA_SECRET;
  private baseUrl = ALPACA_API;

  private getHeaders() {
    return {
      'Authorization': `Basic ${Buffer.from(`${this.apiKey}:${this.apiSecret}`).toString('base64')}`,
      'Content-Type': 'application/json',
    };
  }

  // =========================================================================
  // ACCOUNT & POSITIONS
  // =========================================================================

  async getAccount() {
    try {
      const res = await axios.get(`${this.baseUrl}/account`, {
        headers: this.getHeaders(),
      });
      return res.data;
    } catch (error) {
      console.error('Error getting account:', error);
      return null;
    }
  }

  async getPositions() {
    try {
      const res = await axios.get(`${this.baseUrl}/positions`, {
        headers: this.getHeaders(),
      });
      return res.data;
    } catch (error) {
      console.error('Error getting positions:', error);
      return [];
    }
  }

  // =========================================================================
  // ORDERS
  // =========================================================================

  async placeOrder(params: {
    symbol: string;
    qty?: number;
    notional?: number;
    side: 'buy' | 'sell';
    type: 'market' | 'limit' | 'stop' | 'stop_limit';
    time_in_force?: string;
    limit_price?: number;
    stop_price?: number;
  }) {
    try {
      const res = await axios.post(`${this.baseUrl}/orders`, params, {
        headers: this.getHeaders(),
      });
      return { success: true, order: res.data };
    } catch (error: any) {
      return { success: false, error: error.response?.data || error.message };
    }
  }

  async getOrders(status: 'all' | 'open' | 'closed' = 'all') {
    try {
      const res = await axios.get(`${this.baseUrl}/orders?status=${status}&limit=500`, {
        headers: this.getHeaders(),
      });
      return res.data;
    } catch (error) {
      console.error('Error getting orders:', error);
      return [];
    }
  }

  async cancelOrder(orderId: string) {
    try {
      await axios.delete(`${this.baseUrl}/orders/${orderId}`, {
        headers: this.getHeaders(),
      });
      return { success: true };
    } catch (error) {
      return { success: false, error };
    }
  }

  // =========================================================================
  // ASSETS & MARKET DATA
  // =========================================================================

  async getAssets(filter?: { status?: string; asset_class?: string; tradable?: boolean }) {
    try {
      const params = new URLSearchParams();
      if (filter?.status) params.append('status', filter.status);
      if (filter?.asset_class) params.append('class', filter.asset_class);
      if (filter?.tradable !== undefined) params.append('tradable', String(filter.tradable));

      const res = await axios.get(`${this.baseUrl}/assets?${params}`, {
        headers: this.getHeaders(),
      });
      return res.data;
    } catch (error) {
      console.error('Error getting assets:', error);
      return [];
    }
  }

  async getLatestTrade(symbol: string) {
    try {
      const res = await axios.get(`${this.baseUrl}/last/trades?symbols=${symbol}`, {
        headers: this.getHeaders(),
      });
      return res.data?.trades?.[symbol];
    } catch (error) {
      console.error('Error getting latest trade:', error);
      return null;
    }
  }

  // =========================================================================
  // BARS (Historical Data)
  // =========================================================================

  async getBars(symbol: string, timeframe: string = '1Day', limit: number = 100) {
    try {
      const res = await axios.get(
        `${this.baseUrl}/bars?symbols=${symbol}&timeframe=${timeframe}&limit=${limit}`,
        { headers: this.getHeaders() }
      );
      return res.data?.bars?.[symbol] || [];
    } catch (error) {
      console.error('Error getting bars:', error);
      return [];
    }
  }
}

// Export singleton
export const alpacaClient = new AlpacaClient();

// ============================================================================
// BOT DEPLOYMENT - Wave System
// ============================================================================

export interface BotOrder {
  symbol: string;
  qty: number;
  side: 'buy' | 'sell';
  type: 'market' | 'limit';
  limit_price?: number;
  take_profit?: number;
  stop_loss?: number;
}

export class BotDeployer {
  private client = alpacaClient;
  private orders: BotOrder[] = [];

  setOrders(orders: BotOrder[]) {
    this.orders = orders;
  }

  async deployWaves(waveSize: number = 15, delayMs: number = 90000) {
    const results = [];

    for (let i = 0; i < this.orders.length; i += waveSize) {
      const wave = this.orders.slice(i, i + waveSize);
      const waveNum = Math.floor(i / waveSize) + 1;

      console.log(`🌊 Deploying Wave ${waveNum} (${wave.length} orders)`);

      for (const order of wave) {
        const result = await this.client.placeOrder({
          symbol: order.symbol,
          qty: order.qty,
          side: order.side,
          type: order.type,
          limit_price: order.limit_price,
        });

        results.push({
          symbol: order.symbol,
          wave: waveNum,
          ...result,
        });
      }

      // Wait before next wave (except last)
      if (i + waveSize < this.orders.length) {
        console.log(`⏳ Waiting ${delayMs / 1000}s for next wave...`);
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
    }

    return results;
  }
}

export const botDeployer = new BotDeployer();
