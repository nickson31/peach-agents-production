'use client'

import { createContext, useContext, useState, useCallback, type ReactNode } from 'react'
import type { Report, ReportSource } from './peach-data'

// ─────────────────────────────────────────────
// Research Context — shared between Chat and Peach
// Stores web search results rewritten by OpenRouter
// ─────────────────────────────────────────────

interface ResearchContextValue {
  reports: Report[]
  addReport: (report: Omit<Report, 'id' | 'createdAt'>) => void
  clearReports: () => void
}

const ResearchContext = createContext<ResearchContextValue | null>(null)

export function ResearchProvider({ children }: { children: ReactNode }) {
  const [reports, setReports] = useState<Report[]>([])

  const addReport = useCallback((report: Omit<Report, 'id' | 'createdAt'>) => {
    const newReport: Report = {
      ...report,
      id: `rpt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      createdAt: new Date().toISOString(),
    }
    setReports((prev) => [newReport, ...prev])
  }, [])

  const clearReports = useCallback(() => setReports([]), [])

  return (
    <ResearchContext.Provider value={{ reports, addReport, clearReports }}>
      {children}
    </ResearchContext.Provider>
  )
}

export function useResearch() {
  const ctx = useContext(ResearchContext)
  if (!ctx) throw new Error('useResearch must be used within ResearchProvider')
  return ctx
}

// Helper to create a report from Brave results + OpenRouter summary
export function createReportFromWebSearch(
  query: string,
  summary: string,
  sources: { title: string; url: string; description: string }[]
): Omit<Report, 'id' | 'createdAt'> {
  return {
    type: 'daily',
    title: `Web Search: ${query.slice(0, 60)}${query.length > 60 ? '...' : ''}`,
    session: 'Global',
    assetsFocus: extractTopics(query),
    priority: 'medium',
    body: summary,
    sources: sources.slice(0, 5).map((s) => ({ name: getDomainName(s.url), url: s.url })),
  }
}

function extractTopics(query: string): string[] {
  const topics: string[] = []
  const q = query.toLowerCase()
  if (/crypto|bitcoin|btc|ethereum|eth|defi|web3|blockchain/.test(q)) topics.push('Crypto')
  if (/invest|investor|vc|capital|funding/.test(q)) topics.push('Investment')
  if (/founder|startup|empresa/.test(q)) topics.push('Startups')
  if (/spain|españa|madrid|barcelona/.test(q)) topics.push('Spain')
  if (/trading|forex|market/.test(q)) topics.push('Trading')
  if (topics.length === 0) {
    // Extract first 2 meaningful words
    const words = query.split(/\s+/).filter((w) => w.length > 3).slice(0, 2)
    topics.push(...words.map((w) => w.charAt(0).toUpperCase() + w.slice(1)))
  }
  return topics.slice(0, 4)
}

function getDomainName(url: string): string {
  try {
    const u = new URL(url)
    return u.hostname.replace(/^www\./, '').split('.')[0]
  } catch {
    return 'web'
  }
}
