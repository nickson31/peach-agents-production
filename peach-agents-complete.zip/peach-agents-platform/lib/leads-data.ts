// ─────────────────────────────────────────────
// Lead type — matches cards_demo_es.json schema
// ─────────────────────────────────────────────

import rawJson from '../data/cards_demo_es.json'

export interface LeadMetrics {
  capital_score: number
  crypto_score: number
  priority_dual_score: number
  lead_quality_score: number
}

export interface LeadDetail {
  areas: string[]
  experiencia: string[]
  educacion: string[]
  idiomas: string[]
  industrias: string[]
}

export interface Lead {
  row_id: number
  nombre_completo: string
  subtitulo_tarjeta: string
  ubicacion_tarjeta: string
  resumen_tarjeta: string
  badges_tarjeta: string[]
  metricas_tarjeta: LeadMetrics
  highlights_tarjeta: string[]
  detalle_expandible: LeadDetail
}

// ─────────────────────────────────────────────
// Load from real data file (data/cards_demo_es.json)
// ─────────────────────────────────────────────

const raw = rawJson as Lead[]

// De-duplicate highlights — removes exact dupes and near-dupes with
// trailing punctuation differences (the JSON often repeats the last item)
function dedupeHighlights(leads: Lead[]): Lead[] {
  return leads.map((l) => {
    const seen = new Set<string>()
    const deduped: string[] = []
    for (const h of l.highlights_tarjeta) {
      const key = h.toLowerCase().replace(/[.,;:\s]+$/, '').trim()
      if (!seen.has(key)) {
        seen.add(key)
        deduped.push(h)
      }
    }
    return { ...l, highlights_tarjeta: deduped }
  })
}

export const LEADS: Lead[] = dedupeHighlights(raw)

// Alias for backwards compatibility
export const MOCK_LEADS = LEADS
