// ─────────────────────────────────────────────
// Peach report type — ready to connect CRON + Brave Search
// ─────────────────────────────────────────────

export type ReportType = 'pre_london' | 'pre_newyork' | 'daily' | 'weekly' | 'night'
export type ReportSession = 'London' | 'NewYork' | 'Global'
export type ReportPriority = 'high' | 'medium'

export interface ReportSource {
  name: string
  url: string
}

export interface Report {
  id: string
  type: ReportType
  title: string
  createdAt: string  // ISO timestamp
  session: ReportSession
  assetsFocus: string[]
  priority: ReportPriority
  body: string
  sources: ReportSource[]
}

export const REPORT_TYPE_LABELS: Record<ReportType, string> = {
  pre_london: 'Pre-London',
  pre_newyork: 'Pre-New York',
  daily: 'Daily Macro',
  weekly: 'Weekly Macro',
  night: 'Night Wrap',
}

// Sample reports — replace with CRON-generated data
export const SAMPLE_REPORTS: Report[] = [
  {
    id: 'rpt-001',
    type: 'daily',
    title: 'Daily Macro Brief — 16 Mar 2026',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(),
    session: 'Global',
    assetsFocus: ['EURUSD', 'GBPUSD', 'XAUUSD'],
    priority: 'high',
    body: `**Panorama macro del día**\n\nLos mercados abren con sesgo mixto ante la publicación del IPC americano esta tarde. El consenso apunta a una lectura del 3.2% interanual, ligeramente por encima del objetivo de la Fed.\n\n**EURUSD**\n\nEl par mantiene soporte en 1.0840 tras el dato de PMI manufacturero europeo publicado esta mañana (49.3, en contracción). El BCE mantiene tono dovish, con expectativas de recorte en junio consolidándose en el mercado de futuros.\n\n**GBPUSD**\n\nLa libra aguanta mejor que el euro ante datos mixtos del mercado laboral británico. Desempleo estable en 4.2%, pero los salarios moderándose hacia el 5.8% desde el 6.1% anterior. El Banco de Inglaterra mantiene postura de "higher for longer" aunque con menos convicción.\n\n**Gold / XAUUSD**\n\nEl oro cotiza cerca de máximos en 2.640$/oz. Las posiciones largas especulativas siguen elevadas según el informe COT. El riesgo geopolítico en Oriente Medio actúa como soporte estructural. Un dato de IPC americano por encima de lo esperado podría desencadenar una corrección hacia 2.580$.`,
    sources: [
      { name: 'Reuters', url: 'https://reuters.com' },
      { name: 'MarketWatch', url: 'https://marketwatch.com' },
      { name: 'Forex Factory', url: 'https://forexfactory.com' },
    ],
  },
  {
    id: 'rpt-002',
    type: 'pre_london',
    title: 'Pre-London Brief — 16 Mar 2026',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    session: 'London',
    assetsFocus: ['EURUSD', 'GBPUSD', 'XAUUSD'],
    priority: 'high',
    body: `**Preparación sesión Londres**\n\nLa apertura europea se anticipa con cautela. Los futuros del DAX ceden un 0.3% y el FTSE100 apunta plano. El dólar mantiene fortaleza relativa antes del dato americano de esta tarde.\n\n**Eventos clave de la mañana**\n\n- 09:00 CET: PMI servicios zona euro final (consenso 50.6)\n- 09:30 CET: PMI servicios UK final (consenso 51.2)\n- 10:00 CET: Ventas minoristas Eurozona (consenso -0.2%)\n\n**Narrativa dominante**\n\nEl mercado opera en modo "wait and see" antes del IPC americano. Los traders de EUR/GBP esperan el diferencial de PMI servicios para calibrar la presión relativa. Un PMI servicios UK por encima de 51.5 podría impulsar GBP brevemente.\n\n**Sesgos de precio probables**\n\nEURUSD: Rango 1.0820-1.0880. Sesgo levemente bajista si el PMI euro decepciona.\nGBPUSD: Soporte en 1.2680. Resistencia en 1.2740.\nOro: Consolidación en 2.620-2.650 hasta el dato americano.`,
    sources: [
      { name: 'FXStreet', url: 'https://fxstreet.com' },
      { name: 'DailyFX', url: 'https://dailyfx.com' },
    ],
  },
  {
    id: 'rpt-003',
    type: 'night',
    title: 'Night Market Wrap — 15 Mar 2026',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 14).toISOString(),
    session: 'Global',
    assetsFocus: ['EURUSD', 'XAUUSD'],
    priority: 'medium',
    body: `**Resumen del día**\n\nJornada de corrección moderada en renta variable americana. El S&P500 cerró con una caída del 0.6% tras comentarios hawkish de varios miembros de la Fed. El dólar se fortaleció en todos los cruces.\n\n**Cambios de sentimiento observados**\n\nEl cambio más relevante del día fue el giro en las expectativas de tipos. Los mercados pasaron de descontar 3 recortes en 2026 a solo 2, lo que presionó los bonos del Tesoro y al alza el yield del T10 hacia el 4.28%.\n\nEl euro encajó el golpe con relativa calma dado que el diferencial Fed-BCE ya estaba relativamente en precio. Sin embargo, cualquier dato americano fuerte mañana podría empujar EURUSD hacia 1.0780.\n\n**Preparación para mañana**\n\nFoco total en el IPC americano de las 14:30 CET. El mercado está posicionado para la cifra. Una sorpresa en cualquier dirección puede generar volatilidad significativa en oro y dólar. La semana que viene llega la reunión del FOMC — este dato será interpretado en clave de guidance.`,
    sources: [
      { name: 'Bloomberg', url: 'https://bloomberg.com' },
      { name: 'CNBC', url: 'https://cnbc.com' },
    ],
  },
]
