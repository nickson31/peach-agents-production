'use client'

import React, { createContext, useCallback, useContext, useState } from 'react'
import type { Lead } from '@/lib/leads-data'

// ─────────────────────────────────────────────
// Folder type
// ─────────────────────────────────────────────
export interface LeadsFolder {
  id: string
  name: string
  leads: Lead[]
  isStatic?: boolean  // static folders (Leads, Archivados) survive resets
}

// ─────────────────────────────────────────────
// Context
// ─────────────────────────────────────────────
interface LeadsContextValue {
  folders: LeadsFolder[]
  addLeadToFolder: (folderId: string, lead: Lead) => void
  createFolder: (name: string, leads?: Lead[]) => string
  renameFolder: (folderId: string, name: string) => void
  resetDynamicFolders: () => void
}

const LeadsContext = createContext<LeadsContextValue | null>(null)

const STATIC_FOLDERS: LeadsFolder[] = [
  { id: 'leads', name: 'Leads', leads: [], isStatic: true },
  { id: 'archivados', name: 'Archivados', leads: [], isStatic: true },
]

export function LeadsProvider({ children }: { children: React.ReactNode }) {
  const [folders, setFolders] = useState<LeadsFolder[]>(STATIC_FOLDERS)

  const addLeadToFolder = useCallback((folderId: string, lead: Lead) => {
    setFolders((prev) =>
      prev.map((f) =>
        f.id === folderId
          ? f.leads.find((l) => l.row_id === lead.row_id)
            ? f
            : { ...f, leads: [...f.leads, lead] }
          : f
      )
    )
  }, [])

  const createFolder = useCallback((name: string, leads: Lead[] = []) => {
    const id = `folder-${Date.now()}`
    setFolders((prev) => [...prev, { id, name, leads, isStatic: false }])
    return id
  }, [])

  const renameFolder = useCallback((folderId: string, name: string) => {
    setFolders((prev) =>
      prev.map((f) => (f.id === folderId ? { ...f, name } : f))
    )
  }, [])

  const resetDynamicFolders = useCallback(() => {
    setFolders((prev) => {
      const staticFolders = prev.filter((f) => f.isStatic).map((f) => ({ ...f, leads: [] }))
      return staticFolders
    })
  }, [])

  return (
    <LeadsContext.Provider
      value={{ folders, addLeadToFolder, createFolder, renameFolder, resetDynamicFolders }}
    >
      {children}
    </LeadsContext.Provider>
  )
}

export function useLeads() {
  const ctx = useContext(LeadsContext)
  if (!ctx) throw new Error('useLeads must be used inside LeadsProvider')
  return ctx
}
