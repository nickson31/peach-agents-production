/**
 * PEACH&AGENTS - SECURE AUTHENTICATION
 * Single-user mode with JWT tokens
 * No API limits - self-hosted
 */

import { jwtVerify, SignJWT } from 'jose';
import bcrypt from 'bcryptjs';

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || 'peach-agents-ultra-secure-key-2026-only-you'
);

const MASTER_USER = {
  id: 'peach-master',
  username: 'peach',
  email: process.env.PEACH_EMAIL || 'you@peach-agents.local',
  password_hash: '', // Will be set below
};

// Hash the master password on startup
async function initMasterPassword() {
  const masterPassword = process.env.PEACH_PASSWORD || 'PeachAgents2026!Secure';
  MASTER_USER.password_hash = await bcrypt.hash(masterPassword, 12);
}

initMasterPassword().catch(console.error);

// ============================================================================
// TOKEN GENERATION
// ============================================================================

export async function generateToken(userId: string, expiresIn: string = '7d') {
  const token = await new SignJWT({ userId, iat: Date.now() })
    .setProtectedHeader({ alg: 'HS256' })
    .setExpirationTime(expiresIn)
    .sign(JWT_SECRET);

  return token;
}

// ============================================================================
// TOKEN VERIFICATION
// ============================================================================

export async function verifyToken(token: string) {
  try {
    const verified = await jwtVerify(token, JWT_SECRET);
    return verified.payload as { userId: string; iat: number };
  } catch (error) {
    return null;
  }
}

// ============================================================================
// LOGIN
// ============================================================================

export async function login(username: string, password: string) {
  // Only allow master user
  if (username !== MASTER_USER.username) {
    return { success: false, error: 'User not found' };
  }

  // Verify password
  const passwordMatch = await bcrypt.compare(password, MASTER_USER.password_hash);
  if (!passwordMatch) {
    return { success: false, error: 'Invalid password' };
  }

  // Generate token
  const token = await generateToken(MASTER_USER.id);

  return {
    success: true,
    token,
    user: {
      id: MASTER_USER.id,
      username: MASTER_USER.username,
      email: MASTER_USER.email,
    },
  };
}

// ============================================================================
// GET MASTER USER
// ============================================================================

export function getMasterUser() {
  return {
    id: MASTER_USER.id,
    username: MASTER_USER.username,
    email: MASTER_USER.email,
  };
}

// ============================================================================
// MIDDLEWARE: Check Token
// ============================================================================

export async function checkAuth(authHeader?: string) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }

  const token = authHeader.substring(7);
  return await verifyToken(token);
}
