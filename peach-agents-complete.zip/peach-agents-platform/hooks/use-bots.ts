/**
 * useBotsManagement Hook
 * Create, manage, deploy, and monitor trading bots
 */

import { useCallback, useState } from 'react';

export interface Bot {
  id: string;
  name: string;
  strategy: string;
  symbols: string[];
  allocation: Record<string, number>;
  status: 'idle' | 'deploying' | 'monitoring' | 'completed';
  stats: {
    ordersDeployed: number;
    ordersFilled: number;
    fillRate: number;
    pnl: number;
    createdAt: Date;
  };
  config: {
    takeProfit: number;
    stopLoss: number;
    batchSize: number;
    waveInterval: number;
  };
}

export interface BotFolder {
  id: string;
  name: string;
  description: string;
  bots: Bot[];
  createdAt: Date;
}

export function useBotsManagement() {
  const [bots, setBots] = useState<Bot[]>([]);
  const [folders, setFolders] = useState<BotFolder[]>([]);
  const [selectedBot, setSelectedBot] = useState<Bot | null>(null);
  const [loading, setLoading] = useState(false);

  // =========================================================================
  // BOT CRUD
  // =========================================================================

  const createBot = useCallback(
    async (data: Omit<Bot, 'id' | 'status' | 'stats'>) => {
      setLoading(true);
      try {
        const newBot: Bot = {
          ...data,
          id: `bot-${Date.now()}`,
          status: 'idle',
          stats: {
            ordersDeployed: 0,
            ordersFilled: 0,
            fillRate: 0,
            pnl: 0,
            createdAt: new Date(),
          },
        };

        setBots([...bots, newBot]);
        setSelectedBot(newBot);
        return newBot;
      } finally {
        setLoading(false);
      }
    },
    [bots]
  );

  const updateBot = useCallback(
    (botId: string, updates: Partial<Bot>) => {
      setBots(bots.map(bot => (bot.id === botId ? { ...bot, ...updates } : bot)));
    },
    [bots]
  );

  const deleteBot = useCallback(
    (botId: string) => {
      setBots(bots.filter(bot => bot.id !== botId));
      if (selectedBot?.id === botId) setSelectedBot(null);
    },
    [bots, selectedBot]
  );

  // =========================================================================
  // FOLDER MANAGEMENT
  // =========================================================================

  const createFolder = useCallback(
    (name: string, description: string) => {
      const newFolder: BotFolder = {
        id: `folder-${Date.now()}`,
        name,
        description,
        bots: [],
        createdAt: new Date(),
      };

      setFolders([...folders, newFolder]);
      return newFolder;
    },
    [folders]
  );

  const moveBotsToFolder = useCallback(
    (botIds: string[], folderId: string) => {
      setFolders(
        folders.map(folder => {
          if (folder.id === folderId) {
            return {
              ...folder,
              bots: [...folder.bots, ...bots.filter(b => botIds.includes(b.id))],
            };
          }
          return folder;
        })
      );
    },
    [bots, folders]
  );

  // =========================================================================
  // DEPLOYMENT
  // =========================================================================

  const deployBot = useCallback(
    async (botId: string) => {
      const bot = bots.find(b => b.id === botId);
      if (!bot) return;

      setLoading(true);
      try {
        updateBot(botId, { status: 'deploying' });

        // Simulate wave deployment
        const response = await fetch('/api/bots/deploy', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ botId, ...bot }),
        });

        if (!response.ok) throw new Error('Deployment failed');

        const result = await response.json();

        updateBot(botId, {
          status: 'monitoring',
          stats: {
            ...bot.stats,
            ordersDeployed: result.ordersDeployed,
            ordersFilled: result.ordersFilled,
            fillRate: result.fillRate,
          },
        });
      } finally {
        setLoading(false);
      }
    },
    [bots, updateBot]
  );

  // =========================================================================
  // STATS & MONITORING
  // =========================================================================

  const updateBotStats = useCallback(
    (botId: string, stats: Partial<Bot['stats']>) => {
      updateBot(botId, {
        stats: {
          ...bots.find(b => b.id === botId)?.stats!,
          ...stats,
        },
      });
    },
    [bots, updateBot]
  );

  return {
    bots,
    folders,
    selectedBot,
    loading,
    createBot,
    updateBot,
    deleteBot,
    createFolder,
    moveBotsToFolder,
    deployBot,
    updateBotStats,
    setSelectedBot,
  };
}
