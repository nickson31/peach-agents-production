'use client'

import { useState, useRef, useCallback } from 'react'
import type { Lead } from '@/lib/leads-data'
import { STORAGE_KEY_OPENROUTER, STORAGE_KEY_BRAVE, STORAGE_KEY_MODEL } from '@/components/keys-setup'

// ─────────────────────────────────────────────
// Read a key from localStorage first, then env var as fallback
// ─────────────────────────────────────────────
function getKey(storageKey: string, envKey: string): string {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem(storageKey)
    if (stored) return stored
  }
  return process.env[envKey] ?? ''
}

// ─────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────
export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
  action?: {
    type: 'create_folder'
    folderName: string
    leads: Lead[]
  }
  webResults?: BraveResult[]
}

export interface BraveResult {
  title: string
  url: string
  description: string
}

interface UseLeadsAssistantOptions {
  model?: string
}

// ─────────────────────────────────────────────
// Brave Search — server-side proxy to avoid CORS
// Key is passed via x-brave-key header
// ─────────────────────────────────────────────
async function braveSearch(query: string, signal: AbortSignal): Promise<BraveResult[]> {
  const braveKey = getKey(STORAGE_KEY_BRAVE, 'NEXT_PUBLIC_BRAVE_API_KEY')
  if (!braveKey) return []
  try {
    const params = new URLSearchParams({ q: query })
    const res = await fetch(`/api/brave-search?${params}`, {
      signal,
      headers: { 'x-brave-key': braveKey },
    })
    if (!res.ok) return []
    const data = await res.json()
    return data.results ?? []
  } catch {
    return []
  }
}

// ─────────────────────────────────────────────
// Local lead scoring — searches ALL fields of a lead
// ─────────────────────────────────────────────
function scoreLeadForQuery(lead: Lead, q: string, tokens: string[]): number {
  let score = 0

  const allFields = [
    lead.nombre_completo,
    lead.subtitulo_tarjeta,
    lead.ubicacion_tarjeta,
    lead.resumen_tarjeta,
    ...lead.badges_tarjeta,
    ...lead.highlights_tarjeta,
    ...(lead.detalle_expandible?.areas ?? []),
    ...(lead.detalle_expandible?.experiencia ?? []),
    ...(lead.detalle_expandible?.industrias ?? []),
    ...(lead.detalle_expandible?.educacion ?? []),
    ...(lead.detalle_expandible?.idiomas ?? []),
  ].map((f) => (f ?? '').toLowerCase())

  // Exact phrase match (high weight)
  for (const field of allFields) {
    if (field.includes(q)) score += 5
  }

  // Token match
  for (const token of tokens) {
    for (const field of allFields) {
      if (field.includes(token)) score += 1
    }
  }

  // Metric boosts
  const qFull = q
  if (/crypto|crypt|bitcoin|ethereum|defi|web3|blockchain/.test(qFull))
    score += lead.metricas_tarjeta.crypto_score / 15
  if (/capital|dinero|inversor|investor|hnwi|patrimonio|wealthy/.test(qFull))
    score += lead.metricas_tarjeta.capital_score / 15
  if (/calidad|mejor|top|quality|elite|high/.test(qFull))
    score += lead.metricas_tarjeta.lead_quality_score / 15
  if (/dual|prioridad|priority/.test(qFull))
    score += lead.metricas_tarjeta.priority_dual_score / 15

  // Invert capital score if explicitly asking for low capital
  if (/poco capital|low capital|sin capital/.test(qFull))
    score += (100 - lead.metricas_tarjeta.capital_score) / 15

  // Badge boosts
  const badgeLower = lead.badges_tarjeta.map((b) => b.toLowerCase())
  if (/founder/.test(qFull) && badgeLower.some((b) => b.includes('founder'))) score += 6
  if (/advisor/.test(qFull) && badgeLower.some((b) => b.includes('advisor'))) score += 6
  if (/investor|inversor/.test(qFull) && badgeLower.some((b) => b.includes('investor'))) score += 6
  if (/internacional|international/.test(qFull) && badgeLower.some((b) => b.includes('internacional'))) score += 4
  if (/multilingue|multilingual/.test(qFull) && badgeLower.some((b) => b.includes('multilingü'))) score += 4

  return score
}

function searchLeads(query: string, leads: Lead[]): Lead[] {
  const q = query.toLowerCase().trim()
  const tokens = q.split(/\s+/).filter((t) => t.length > 2)
  const scored = leads
    .map((lead) => ({ lead, score: scoreLeadForQuery(lead, q, tokens) }))
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score)
  return scored.map((s) => s.lead)
}

function suggestFolderName(query: string, leads: Lead[]): string {
  const q = query.toLowerCase()
  if (/barcelona/.test(q)) return 'Barcelona Leads'
  if (/madrid/.test(q)) return 'Madrid Leads'
  if (/miami/.test(q)) return 'Miami Leads'
  if (/dubai/.test(q)) return 'Dubai Leads'
  if (/crypto|defi|blockchain|web3/.test(q)) return 'Crypto Leads'
  if (/poco capital|low capital/.test(q)) return 'Poco Capital'
  if (/founder/.test(q)) return 'Founders'
  if (/investor|inversor/.test(q)) return 'Investors'
  if (/advisor/.test(q)) return 'Top Advisors'
  if (/mejor|top|best|elite/.test(q)) return 'Top Leads'
  if (leads[0]?.ubicacion_tarjeta && leads[0].ubicacion_tarjeta.toLowerCase() !== 'empty')
    return `${leads[0].ubicacion_tarjeta.split(',')[0]} Leads`
  return 'Nueva Carpeta'
}

// Compact lead summary for the AI context — keeps token count low
function buildLeadContext(lead: Lead, index: number): string {
  return `[${index + 1}] ${lead.nombre_completo} | ${lead.subtitulo_tarjeta} | ${lead.ubicacion_tarjeta !== 'empty' ? lead.ubicacion_tarjeta : 'N/A'} | Badges: ${lead.badges_tarjeta.slice(0, 4).join(', ')} | Quality:${lead.metricas_tarjeta.lead_quality_score} Capital:${lead.metricas_tarjeta.capital_score} Crypto:${lead.metricas_tarjeta.crypto_score} | Areas: ${lead.detalle_expandible.areas.slice(0, 3).join(', ')}`
}

// ─────────────────────────────────────────────
// Intent detection
// ─────────────────────────────────────────────
function detectWebIntent(msg: string): { isWeb: boolean; cleanQuery: string } {
  // Explicit /web command
  if (/^\/web\s+/i.test(msg)) {
    return { isWeb: true, cleanQuery: msg.replace(/^\/web\s+/i, '').trim() }
  }
  // Natural web intent
  const isWeb = /busca.*(web|internet|online)|investiga|noticias|últimas.*noticias|qué.*sabe|información.*sobre|perfil.*público|empresa.*de|linkedin.*de|google|buscar en la web/i.test(msg)
  return { isWeb, cleanQuery: msg }
}

function detectFolderIntent(msg: string): boolean {
  return /carpeta|folder|agrupa|organiza|guarda.*lista|crea.*lista|lista.*crea|ponlos.*juntos/i.test(msg)
}

// ─────────────────────────────────────────────
// Hook
// ─────────────────────────────────────────────
export function useLeadsAssistant({ model: modelProp }: UseLeadsAssistantOptions = {}) {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const abortRef = useRef<AbortController | null>(null)

  // Resolve model: prop > localStorage > default free model
  const resolveModel = useCallback(() => {
    if (modelProp) return modelProp
    const stored = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEY_MODEL) : null
    return stored ?? 'openrouter/free'
  }, [modelProp])

  const sendMessage = useCallback(
    async (
      userMessage: string,
      allLeads: Lead[],
      onCreateFolder?: (name: string, leads: Lead[]) => void,
      braveQueryPrefix?: string,
      onWebResearch?: (query: string, summary: string, sources: BraveResult[]) => void
    ) => {
      if (!userMessage.trim()) return

      const userMsg: ChatMessage = { role: 'user', content: userMessage }
      setMessages((prev) => [...prev, userMsg])
      setIsLoading(true)
      abortRef.current = new AbortController()

      try {
        const { isWeb, cleanQuery } = detectWebIntent(userMessage)
        const isFolderIntent = detectFolderIntent(userMessage)

        // Search the local dataset
        const relevantLeads = searchLeads(cleanQuery, allLeads)
        const topLeads = relevantLeads.slice(0, 15)

        // Brave web search if requested
        let webResults: BraveResult[] = []
        if (isWeb) {
          const searchQuery = braveQueryPrefix
            ? `${braveQueryPrefix} ${cleanQuery}`
            : cleanQuery
          webResults = await braveSearch(searchQuery, abortRef.current.signal)
        }

        const openRouterKey = getKey(STORAGE_KEY_OPENROUTER, 'NEXT_PUBLIC_OPENROUTER_API_KEY')
        const model = resolveModel()

        if (!openRouterKey) {
          // ── Demo mode — local only ──
          await new Promise((r) => setTimeout(r, 500))
          let content = ''
          let action: ChatMessage['action'] | undefined

          if (relevantLeads.length === 0 && webResults.length === 0) {
            content = `No encontré perfiles para "${cleanQuery}". Prueba con ciudad, área (DeFi, Blockchain, VC), tipo (Founder, Investor, Advisor), o un nombre.\n\nPara búsquedas web escribe: /web <consulta>`
          } else if (isFolderIntent) {
            const folderName = suggestFolderName(cleanQuery, relevantLeads)
            const folderLeads = relevantLeads.slice(0, 10)
            content = `Carpeta creada: **${folderName}**\n\n${folderLeads.map((l, i) => `${i + 1}. ${l.nombre_completo} — ${l.subtitulo_tarjeta}`).join('\n')}\n\nYa aparece en la pantalla Leads.`
            action = { type: 'create_folder', folderName, leads: folderLeads }
            if (onCreateFolder) onCreateFolder(folderName, folderLeads)
          } else {
            const top = relevantLeads.slice(0, 6)
            content = `**${relevantLeads.length} perfil${relevantLeads.length !== 1 ? 'es' : ''} encontrado${relevantLeads.length !== 1 ? 's' : ''}:**\n\n${top.map((l, i) => `**${i + 1}. ${l.nombre_completo}**\n${l.subtitulo_tarjeta}${l.ubicacion_tarjeta && l.ubicacion_tarjeta !== 'empty' ? ` · ${l.ubicacion_tarjeta}` : ''}\nCalidad ${l.metricas_tarjeta.lead_quality_score} · Capital ${l.metricas_tarjeta.capital_score} · Crypto ${l.metricas_tarjeta.crypto_score}`).join('\n\n')}${relevantLeads.length > 6 ? `\n\n...y ${relevantLeads.length - 6} más. ¿Los agrupo en una carpeta?` : ''}`
          }

          setMessages((prev) => [
            ...prev,
            { role: 'assistant', content, action, webResults: webResults.length ? webResults : undefined },
          ])
          setIsLoading(false)
          return
        }

        // ── OpenRouter call ──
        const webContext = webResults.length > 0
          ? `\n\nRESULTADOS BRAVE SEARCH:\n${webResults.map((r, i) => `[${i + 1}] ${r.title}\n${r.url}\n${r.description}`).join('\n\n')}`
          : ''

        const leadsContext = topLeads.length > 0
          ? `\nPERFILES ENCONTRADOS (${topLeads.length} de ${relevantLeads.length} matches, ${allLeads.length} total en DB):\n${topLeads.map(buildLeadContext).join('\n')}`
          : `\nBÚSQUEDA: "${cleanQuery}" - No se encontraron coincidencias en los ${allLeads.length} perfiles. Sugiere al usuario probar con otros términos (ciudad, industria, rol, nombre).`

        const systemPrompt = `Eres un asistente de ventas B2B. Tu trabajo es ayudar a buscar y filtrar perfiles de una base de datos de leads.

INSTRUCCIONES:
- Responde siempre en español, conciso y directo
- Cuando el usuario pregunte por perfiles, usa SOLO los datos que te proporciono abajo
- Si hay perfiles relevantes, listarlos con nombre, cargo y ubicación
- NO inventes datos ni digas "no hay resultados" si hay perfiles en el contexto
- Para búsqueda web el usuario escribe /web <consulta>

${leadsContext}${webContext}

IMPORTANTE: Los perfiles arriba son los resultados de la búsqueda. Úsalos para responder.`

        const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${openRouterKey}`,
            'HTTP-Referer': 'https://leads-app.vercel.app',
            'X-Title': 'Leads Assistant',
          },
          signal: abortRef.current.signal,
          body: JSON.stringify({
            model,
            messages: [
              { role: 'system', content: systemPrompt },
              // Include last 6 messages for context (keep token count low)
              ...messages.slice(-6).map((m) => ({ role: m.role, content: m.content })),
              { role: 'user', content: cleanQuery },
            ],
            max_tokens: 600,
          }),
        })

        if (!response.ok) {
          const errBody = await response.text().catch(() => '')
          throw new Error(`OpenRouter ${response.status}: ${errBody}`)
        }

        const data = await response.json()
        const assistantContent = data.choices?.[0]?.message?.content ?? '[sin respuesta]'

        let action: ChatMessage['action'] | undefined
        if (isFolderIntent && relevantLeads.length > 0) {
          const folderName = suggestFolderName(cleanQuery, relevantLeads)
          const folderLeads = relevantLeads.slice(0, 10)
          action = { type: 'create_folder', folderName, leads: folderLeads }
          if (onCreateFolder) onCreateFolder(folderName, folderLeads)
        }

        // If web search was done, call the callback to save to Peach
        if (isWeb && webResults.length > 0 && onWebResearch) {
          onWebResearch(cleanQuery, assistantContent, webResults)
        }

        setMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            content: assistantContent,
            action,
            webResults: webResults.length ? webResults : undefined,
          },
        ])
      } catch (err: unknown) {
        if (err instanceof Error && err.name === 'AbortError') return
        const detail = err instanceof Error ? err.message : String(err)
        setMessages((prev) => [
          ...prev,
          { role: 'assistant', content: `Error: ${detail}` },
        ])
      } finally {
        setIsLoading(false)
      }
    },
    [messages, resolveModel]
  )

  const clearMessages = useCallback(() => setMessages([]), [])
  const stopGeneration = useCallback(() => {
    abortRef.current?.abort()
    setIsLoading(false)
  }, [])

  return { messages, isLoading, sendMessage, clearMessages, stopGeneration }
}
