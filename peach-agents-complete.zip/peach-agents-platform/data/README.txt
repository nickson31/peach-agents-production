LEADS DATA FOLDER
=================

Place your JSON file here as: leads.json

The file must be an array of lead objects with this structure:

[
  {
    "row_id": 0,
    "nombre_completo": "Name Surname",
    "subtitulo_tarjeta": "Professional role",
    "ubicacion_tarjeta": "City, Country",
    "resumen_tarjeta": "Short profile summary",
    "badges_tarjeta": ["Founder", "Investor"],
    "metricas_tarjeta": {
      "capital_score": 90,
      "crypto_score": 95,
      "priority_dual_score": 88,
      "lead_quality_score": 98
    },
    "highlights_tarjeta": ["Highlight 1", "Highlight 2"],
    "detalle_expandible": {
      "areas": ["Blockchain", "DeFi"],
      "experiencia": ["Role at Company"],
      "educacion": ["Degree"],
      "idiomas": ["Spanish", "English"],
      "industrias": ["Finance", "Tech"]
    }
  }
]

IMPORTANT:
- "ubicacion_tarjeta": use "empty" to hide location
- "idiomas": use [] to hide languages section
- "educacion": use [] to hide education section

Once you place the file, update lib/leads-data.ts to load from this path
instead of MOCK_LEADS, or use a server-side API route to read and serve the JSON.
