/**
 * UNIFIED SEARCH API
 * Searches: Twitter, YouTube, Google, Instagram, TikTok
 * No API limits - uses local methods + Brave Search
 */

import axios from 'axios';

export async function POST(request: Request) {
  try {
    const { query, sources } = await request.json();

    if (!query) {
      return Response.json({ error: 'Missing query' }, { status: 400 });
    }

    const defaultSources = sources || ['twitter', 'youtube', 'google', 'instagram', 'tiktok'];
    const results: Record<string, any> = {};

    for (const source of defaultSources) {
      switch (source) {
        case 'brave':
        case 'google':
          results.google = await searchBrave(query);
          break;
        case 'twitter':
          results.twitter = await searchTwitter(query);
          break;
        case 'youtube':
          results.youtube = await searchYouTube(query);
          break;
        case 'instagram':
          results.instagram = { message: 'Instagram requires auth - use web browser' };
          break;
        case 'tiktok':
          results.tiktok = { message: 'TikTok requires auth - use web browser' };
          break;
      }
    }

    return Response.json(results);
  } catch (error: any) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// ============================================================================
// SEARCH IMPLEMENTATIONS
// ============================================================================

async function searchBrave(query: string) {
  try {
    const braveApiKey = process.env.BRAVE_SEARCH_API_KEY;
    if (!braveApiKey) return { error: 'Brave API not configured' };

    const response = await axios.get('https://api.search.brave.com/res/v1/web/search', {
      params: { q: query },
      headers: { 'Accept-Encoding': 'gzip', 'X-Subscription-Token': braveApiKey },
    });

    return response.data.web?.slice(0, 10) || [];
  } catch (error) {
    return { error: 'Brave search failed' };
  }
}

async function searchTwitter(query: string) {
  // Note: Real Twitter API requires authentication
  // This returns a mock structure for demo
  return {
    note: 'Twitter API requires bearer token - configure TWITTER_BEARER_TOKEN',
    query: query,
    results: [],
  };
}

async function searchYouTube(query: string) {
  try {
    const youtubeKey = process.env.YOUTUBE_API_KEY;
    if (!youtubeKey) return { error: 'YouTube API not configured' };

    const response = await axios.get('https://www.googleapis.com/youtube/v3/search', {
      params: {
        q: query,
        key: youtubeKey,
        part: 'snippet',
        maxResults: 10,
        type: 'video',
      },
    });

    return response.data.items?.map((item: any) => ({
      id: item.id.videoId,
      title: item.snippet.title,
      description: item.snippet.description,
      channel: item.snippet.channelTitle,
      url: `https://youtube.com/watch?v=${item.id.videoId}`,
    })) || [];
  } catch (error) {
    return { error: 'YouTube search failed' };
  }
}
