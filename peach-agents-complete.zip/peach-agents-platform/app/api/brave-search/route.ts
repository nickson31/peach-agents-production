import { NextResponse } from 'next/server'

// Server-side proxy for Brave Search API — avoids CORS
// The client passes its key via the x-brave-key header
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get('q')
  if (!query) return NextResponse.json({ error: 'Missing query' }, { status: 400 })

  // Accept key from request header (set by the client hook) or fall back to env var
  const apiKey =
    request.headers.get('x-brave-key') ??
    process.env.NEXT_PUBLIC_BRAVE_API_KEY ??
    ''
  if (!apiKey) return NextResponse.json({ results: [] })

  try {
    const params = new URLSearchParams({ q: query, count: '5', search_lang: 'es' })
    const res = await fetch(`https://api.search.brave.com/res/v1/web/search?${params}`, {
      headers: {
        Accept: 'application/json',
        'Accept-Encoding': 'gzip',
        'X-Subscription-Token': apiKey,
      },
      cache: 'no-store',
    })
    if (!res.ok) {
      console.error('[v0] Brave API error:', res.status, await res.text())
      return NextResponse.json({ results: [] })
    }
    const data = await res.json()
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const results = (data.web?.results ?? []).slice(0, 5).map((r: any) => ({
      title: r.title ?? '',
      url: r.url ?? '',
      description: r.description ?? '',
    }))
    return NextResponse.json({ results })
  } catch (err) {
    console.error('[v0] Brave proxy error:', err)
    return NextResponse.json({ results: [] })
  }
}
