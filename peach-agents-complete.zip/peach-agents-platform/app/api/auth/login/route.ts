import { login } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json();

    if (!username || !password) {
      return Response.json({ error: 'Missing credentials' }, { status: 400 });
    }

    const result = await login(username, password);

    if (!result.success) {
      return Response.json({ error: result.error }, { status: 401 });
    }

    return Response.json({
      token: result.token,
      user: result.user,
    });
  } catch (error) {
    return Response.json({ error: 'Login failed' }, { status: 500 });
  }
}
