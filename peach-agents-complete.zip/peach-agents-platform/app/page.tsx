'use client'

import { useState, useCallback, useEffect } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { SwipeStack } from '@/components/swipe-stack'
import { LeadsList } from '@/components/leads-list'
import { ChatInterface } from '@/components/chat-interface'
import { PeachScreen } from '@/components/peach-screen'
import { TabBar } from '@/components/tab-bar'
import { LeadsProvider } from '@/lib/leads-context'
import { ResearchProvider } from '@/lib/research-context'
import { LEADS } from '@/lib/leads-data'
import { KeysSetup, getStoredKeys } from '@/components/keys-setup'

export type View = 'chat' | 'swipe' | 'peach' | 'leads'

const VIEW_ORDER: View[] = ['chat', 'swipe', 'peach', 'leads']

const slideVariants = {
  enter: (dir: number) => ({ x: dir > 0 ? '100%' : '-100%', opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (dir: number) => ({ x: dir < 0 ? '100%' : '-100%', opacity: 0 }),
}

function AppContent() {
  const [view, setView] = useState<View>('chat')
  const [prevView, setPrevView] = useState<View>('chat')
  // null = not yet checked (waiting for mount), true = show setup, false = ready
  const [showSetup, setShowSetup] = useState<boolean | null>(null)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)

  useEffect(() => {
    const { openrouter } = getStoredKeys()
    setShowSetup(!openrouter)
  }, [])

  const navigate = useCallback(
    (next: View) => {
      setPrevView(view)
      setView(next)
    },
    [view]
  )

  const openSettings = useCallback(() => setIsSettingsOpen(true), [])

  const viewDirection =
    VIEW_ORDER.indexOf(view) >= VIEW_ORDER.indexOf(prevView) ? 1 : -1

  return (
    <>
      {/* Main app */}
      <main
        className="relative flex flex-col w-full overflow-hidden bg-background"
        style={{ height: '100dvh' }}
      >
        <div className="flex-1 relative overflow-hidden">
          <AnimatePresence initial={false} custom={viewDirection} mode="wait">
            {view === 'chat' && (
              <motion.div
                key="chat"
                custom={viewDirection}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.2, ease: 'easeInOut' }}
                className="absolute inset-0"
              >
                <ChatInterface onOpenSettings={openSettings} />
              </motion.div>
            )}

            {view === 'swipe' && (
              <motion.div
                key="swipe"
                custom={viewDirection}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.2, ease: 'easeInOut' }}
                className="absolute inset-0"
              >
                <SwipeStack leads={LEADS} />
              </motion.div>
            )}

            {view === 'peach' && (
              <motion.div
                key="peach"
                custom={viewDirection}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.2, ease: 'easeInOut' }}
                className="absolute inset-0"
              >
                <PeachScreen />
              </motion.div>
            )}

            {view === 'leads' && (
              <motion.div
                key="leads"
                custom={viewDirection}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.2, ease: 'easeInOut' }}
                className="absolute inset-0"
              >
                <LeadsList />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <TabBar activeView={view} onNavigate={navigate} />
      </main>

      {/* Initial keys setup overlay */}
      <AnimatePresence>
        {showSetup === true && (
          <KeysSetup onDone={() => setShowSetup(false)} />
        )}
      </AnimatePresence>

      {/* Settings re-open overlay */}
      <AnimatePresence>
        {isSettingsOpen && (
          <KeysSetup isSettings onDone={() => setIsSettingsOpen(false)} />
        )}
      </AnimatePresence>
    </>
  )
}

export default function Page() {
  return (
    <LeadsProvider>
      <ResearchProvider>
        <AppContent />
      </ResearchProvider>
    </LeadsProvider>
  )
}
