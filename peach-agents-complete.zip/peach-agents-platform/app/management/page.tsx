/**
 * MANAGEMENT PAGE - Central Hub for Bots, Leads, Strategies
 * Page 4: Leads → Management (evolved)
 */

'use client';

import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useBotsManagement } from '@/hooks/use-bots';
import { Plus, BarChart3, Settings2, FolderOpen } from 'lucide-react';

export default function ManagementPage() {
  const {
    bots,
    folders,
    selectedBot,
    createBot,
    createFolder,
    deployBot,
    updateBotStats,
  } = useBotsManagement();

  const [activeTab, setActiveTab] = useState('bots');
  const [showNewBotDialog, setShowNewBotDialog] = useState(false);

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-bold">Management Center</h1>
        <p className="text-gray-500">Manage bots, leads, strategies, and organizations</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="bots">
            <BarChart3 className="mr-2 h-4 w-4" />
            Bots
          </TabsTrigger>
          <TabsTrigger value="strategies">
            <Settings2 className="mr-2 h-4 w-4" />
            Strategies
          </TabsTrigger>
          <TabsTrigger value="folders">
            <FolderOpen className="mr-2 h-4 w-4" />
            Folders
          </TabsTrigger>
          <TabsTrigger value="analytics">
            <BarChart3 className="mr-2 h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        {/* BOTS TAB */}
        <TabsContent value="bots" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Trading Bots</h2>
            <Button onClick={() => setShowNewBotDialog(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create Bot
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {bots.length === 0 ? (
              <Card className="col-span-full">
                <CardContent className="pt-6">
                  <p className="text-center text-gray-500">No bots created yet</p>
                </CardContent>
              </Card>
            ) : (
              bots.map(bot => (
                <Card key={bot.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg">{bot.name}</CardTitle>
                    <p className="text-sm text-gray-500">{bot.strategy}</p>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm">
                      <p className="text-gray-600">Symbols: {bot.symbols.join(', ')}</p>
                      <p className="text-gray-600">Status: {bot.status}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <p className="text-gray-500">Fill Rate</p>
                        <p className="font-bold">{bot.stats.fillRate.toFixed(1)}%</p>
                      </div>
                      <div>
                        <p className="text-gray-500">P&L</p>
                        <p className={`font-bold ${bot.stats.pnl > 0 ? 'text-green-600' : 'text-red-600'}`}>
                          ${bot.stats.pnl.toFixed(2)}
                        </p>
                      </div>
                    </div>

                    {bot.status === 'idle' && (
                      <Button
                        className="w-full"
                        onClick={() => deployBot(bot.id)}
                      >
                        Deploy
                      </Button>
                    )}
                    {bot.status === 'deploying' && (
                      <Button disabled className="w-full">
                        Deploying...
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        {/* STRATEGIES TAB */}
        <TabsContent value="strategies" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Trading Strategies</h2>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Strategy
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Available Strategies</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {[
                  { name: 'Trend Following', description: 'Buy on uptrend, sell on downtrend' },
                  { name: 'Mean Reversion', description: 'Buy oversold, sell overbought' },
                  { name: 'Scalping', description: 'Small gains, high frequency' },
                  { name: 'Swing Trading', description: 'Multi-day positions' },
                ].map(strategy => (
                  <div
                    key={strategy.name}
                    className="p-3 border rounded hover:bg-gray-50 cursor-pointer"
                  >
                    <p className="font-semibold">{strategy.name}</p>
                    <p className="text-sm text-gray-600">{strategy.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* FOLDERS TAB */}
        <TabsContent value="folders" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Bot Folders</h2>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Folder
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {folders.map(folder => (
              <Card key={folder.id}>
                <CardHeader>
                  <CardTitle>{folder.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">{folder.description}</p>
                  <p className="text-xs text-gray-500 mt-2">
                    {folder.bots.length} bot{folder.bots.length !== 1 ? 's' : ''}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* ANALYTICS TAB */}
        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Portfolio Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Total Bots</p>
                  <p className="text-3xl font-bold">{bots.length}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Active</p>
                  <p className="text-3xl font-bold text-green-600">
                    {bots.filter(b => b.status === 'monitoring').length}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Avg Fill Rate</p>
                  <p className="text-3xl font-bold">
                    {bots.length > 0
                      ? (bots.reduce((sum, b) => sum + b.stats.fillRate, 0) / bots.length).toFixed(1)
                      : '0'}
                    %
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total P&L</p>
                  <p className={`text-3xl font-bold ${
                    bots.reduce((sum, b) => sum + b.stats.pnl, 0) > 0
                      ? 'text-green-600'
                      : 'text-red-600'
                  }`}>
                    ${bots.reduce((sum, b) => sum + b.stats.pnl, 0).toFixed(2)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
