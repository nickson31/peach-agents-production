'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Eye, EyeOff, CheckCircle2, ExternalLink, X, KeyRound, Globe, ChevronDown } from 'lucide-react'

export const STORAGE_KEY_OPENROUTER = 'leads_openrouter_key'
export const STORAGE_KEY_BRAVE = 'leads_brave_key'
export const STORAGE_KEY_BRAVE_QUERY = 'leads_brave_query'
export const STORAGE_KEY_MODEL = 'leads_openrouter_model'

const FREE_MODELS = [
  { id: 'openrouter/free', label: 'Free (gratuito)' },
]

export function getStoredKeys() {
  if (typeof window === 'undefined') return { openrouter: '', brave: '', braveQuery: '', model: '' }
  return {
    openrouter: localStorage.getItem(STORAGE_KEY_OPENROUTER) ?? '',
    brave: localStorage.getItem(STORAGE_KEY_BRAVE) ?? '',
    braveQuery: localStorage.getItem(STORAGE_KEY_BRAVE_QUERY) ?? '',
    model: localStorage.getItem(STORAGE_KEY_MODEL) ?? '',
  }
}

interface KeysSetupProps {
  onDone: () => void
  isSettings?: boolean
}

export function KeysSetup({ onDone, isSettings = false }: KeysSetupProps) {
  const [openrouter, setOpenrouter] = useState('')
  const [brave, setBrave] = useState('')
  const [braveQuery, setBraveQuery] = useState('')
  const [model, setModel] = useState(FREE_MODELS[0].id)
  const [showOr, setShowOr] = useState(false)
  const [showBrave, setShowBrave] = useState(false)
  const [showModelPicker, setShowModelPicker] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    setMounted(true)
    const stored = getStoredKeys()
    if (stored.openrouter) setOpenrouter(stored.openrouter)
    if (stored.brave) setBrave(stored.brave)
    if (stored.braveQuery) setBraveQuery(stored.braveQuery)
    if (stored.model) setModel(stored.model)
  }, [])

  function handleSave() {
    const orKey = openrouter.trim()
    const bKey = brave.trim()
    const bQuery = braveQuery.trim()
    if (!orKey && !isSettings) return

    if (orKey) localStorage.setItem(STORAGE_KEY_OPENROUTER, orKey)
    else localStorage.removeItem(STORAGE_KEY_OPENROUTER)
    if (bKey) localStorage.setItem(STORAGE_KEY_BRAVE, bKey)
    else localStorage.removeItem(STORAGE_KEY_BRAVE)
    if (bQuery) localStorage.setItem(STORAGE_KEY_BRAVE_QUERY, bQuery)
    else localStorage.removeItem(STORAGE_KEY_BRAVE_QUERY)
    localStorage.setItem(STORAGE_KEY_MODEL, model)

    setSaved(true)
    setTimeout(() => {
      setSaved(false)
      onDone()
    }, 800)
  }

  if (!mounted) return null

  const orValid = openrouter.trim().length > 10
  const selectedModel = FREE_MODELS.find((m) => m.id === model) ?? FREE_MODELS[0]

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
      className="fixed inset-0 z-50 flex items-center justify-center px-5"
      style={{ background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(6px)' }}
      onClick={(e) => { if (e.target === e.currentTarget && isSettings) onDone() }}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0, y: 12 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 12 }}
        transition={{ type: 'spring', stiffness: 440, damping: 38 }}
        className="w-full max-w-sm bg-card rounded-3xl shadow-2xl overflow-hidden border border-border"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-border">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center">
              <KeyRound size={15} className="text-primary" />
            </div>
            <div>
              <h2 className="text-base font-bold text-foreground leading-tight">
                {isSettings ? 'Ajustes de API' : 'Configura tus claves'}
              </h2>
              <p className="text-[11px] text-muted-foreground leading-none mt-0.5">
                Solo se guardan en este dispositivo
              </p>
            </div>
          </div>
          {isSettings && (
            <button
              onClick={onDone}
              className="w-7 h-7 flex items-center justify-center rounded-full bg-secondary text-muted-foreground active:bg-muted transition-colors"
              aria-label="Cerrar"
            >
              <X size={14} />
            </button>
          )}
        </div>

        <div className="px-5 py-5 space-y-4 max-h-[80dvh] overflow-y-auto">
          {/* OpenRouter key */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-foreground uppercase tracking-wide">
                OpenRouter{!isSettings && <span className="text-primary ml-0.5">*</span>}
              </label>
              <a
                href="https://openrouter.ai/keys"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-0.5 text-[11px] text-muted-foreground active:text-foreground"
              >
                Obtener clave <ExternalLink size={10} className="ml-0.5" />
              </a>
            </div>
            <div className="relative">
              <input
                type={showOr ? 'text' : 'password'}
                value={openrouter}
                onChange={(e) => setOpenrouter(e.target.value)}
                placeholder="sk-or-v1-..."
                className="w-full h-11 px-3.5 pr-11 rounded-2xl bg-secondary text-foreground text-sm placeholder:text-muted-foreground border border-border focus:outline-none focus:ring-2 focus:ring-primary/25 font-mono"
                autoComplete="off"
                spellCheck={false}
              />
              <button
                type="button"
                onClick={() => setShowOr((v) => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground p-1"
              >
                {showOr ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
            <AnimatePresence>
              {orValid && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-center gap-1 text-[11px] font-medium text-green-600"
                >
                  <CheckCircle2 size={11} /> Clave detectada
                </motion.p>
              )}
            </AnimatePresence>
          </div>

          {/* Model selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-foreground uppercase tracking-wide">
              Modelo IA
            </label>
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowModelPicker((v) => !v)}
                className="w-full h-11 px-3.5 pr-10 rounded-2xl bg-secondary text-foreground text-sm border border-border text-left flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-primary/25"
              >
                <span className="truncate">{selectedModel.label}</span>
                <ChevronDown size={14} className={`text-muted-foreground shrink-0 transition-transform ${showModelPicker ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence>
                {showModelPicker && (
                  <motion.div
                    initial={{ opacity: 0, y: -4, scaleY: 0.95 }}
                    animate={{ opacity: 1, y: 0, scaleY: 1 }}
                    exit={{ opacity: 0, y: -4, scaleY: 0.95 }}
                    transition={{ duration: 0.12 }}
                    className="absolute top-12 left-0 right-0 z-10 bg-card rounded-2xl border border-border shadow-xl overflow-hidden"
                  >
                    {FREE_MODELS.map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => { setModel(m.id); setShowModelPicker(false) }}
                        className={`w-full text-left px-4 py-3 text-sm transition-colors hover:bg-secondary ${model === m.id ? 'font-semibold text-primary bg-primary/5' : 'text-foreground'}`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <p className="text-[11px] text-muted-foreground">Todos los modelos listados son gratuitos en OpenRouter.</p>
          </div>

          {/* Brave key */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-foreground uppercase tracking-wide">
                Brave Search <span className="text-muted-foreground normal-case font-normal tracking-normal">(opcional)</span>
              </label>
              <a
                href="https://api.search.brave.com/register"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-0.5 text-[11px] text-muted-foreground active:text-foreground"
              >
                Obtener clave <ExternalLink size={10} className="ml-0.5" />
              </a>
            </div>
            <div className="relative">
              <input
                type={showBrave ? 'text' : 'password'}
                value={brave}
                onChange={(e) => setBrave(e.target.value)}
                placeholder="BSA..."
                className="w-full h-11 px-3.5 pr-11 rounded-2xl bg-secondary text-foreground text-sm placeholder:text-muted-foreground border border-border focus:outline-none focus:ring-2 focus:ring-primary/25 font-mono"
                autoComplete="off"
                spellCheck={false}
              />
              <button
                type="button"
                onClick={() => setShowBrave((v) => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground p-1"
              >
                {showBrave ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>

          {/* Brave query prefix */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5">
              <Globe size={11} className="text-muted-foreground" />
              <label className="text-xs font-semibold text-foreground uppercase tracking-wide">
                Prefijo búsqueda web <span className="text-muted-foreground normal-case font-normal tracking-normal">(opcional)</span>
              </label>
            </div>
            <input
              type="text"
              value={braveQuery}
              onChange={(e) => setBraveQuery(e.target.value)}
              placeholder="ej: crypto Spain investor LinkedIn"
              className="w-full h-11 px-3.5 rounded-2xl bg-secondary text-foreground text-sm placeholder:text-muted-foreground border border-border focus:outline-none focus:ring-2 focus:ring-primary/25"
              autoComplete="off"
              spellCheck={false}
            />
            <p className="text-[11px] text-muted-foreground leading-snug">
              Se antepone a cada busqueda. En el chat escribe <span className="font-semibold text-foreground">/web [consulta]</span> para forzar una busqueda web.
            </p>
          </div>

          {/* CTA */}
          <button
            onClick={handleSave}
            disabled={!isSettings && !openrouter.trim()}
            className="w-full h-12 rounded-2xl font-bold text-sm transition-all active:scale-[0.98] disabled:opacity-40 flex items-center justify-center gap-2"
            style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
          >
            <AnimatePresence mode="wait">
              {saved ? (
                <motion.span key="saved" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-1.5">
                  <CheckCircle2 size={15} /> Guardado
                </motion.span>
              ) : (
                <motion.span key="save" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                  {isSettings ? 'Guardar cambios' : 'Entrar'}
                </motion.span>
              )}
            </AnimatePresence>
          </button>

          {!isSettings && (
            <button
              onClick={onDone}
              className="w-full text-center text-xs text-muted-foreground active:text-foreground transition-colors pb-1"
            >
              Continuar sin claves (modo demo)
            </button>
          )}
        </div>
      </motion.div>
    </motion.div>
  )
}
