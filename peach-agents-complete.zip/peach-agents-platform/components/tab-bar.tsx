'use client'

import { motion } from 'framer-motion'
import { MessageCircle, Layers, TrendingUp } from 'lucide-react'
import type { View } from '@/app/page'

// Custom Swipe icon
function SwipeIcon({ size, active }: { size: number; active: boolean }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={active ? 'var(--primary)' : 'var(--muted-foreground)'}
      strokeWidth={active ? 2.5 : 1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M8 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2" />
      <path d="M10 2h4v4h-4z" />
      <path d="M9 14l2 2 4-4" />
    </svg>
  )
}

interface TabBarProps {
  activeView: View
  onNavigate: (view: View) => void
}

const tabs: { id: View; label: string }[] = [
  { id: 'chat', label: 'Chat' },
  { id: 'swipe', label: 'Swipe' },
  { id: 'peach', label: 'Peach' },
  { id: 'leads', label: 'Leads' },
]

function TabIcon({ id, active }: { id: View; active: boolean }) {
  const size = 22
  if (id === 'chat') return <MessageCircle size={size} strokeWidth={active ? 2.5 : 1.8} style={{ color: active ? 'var(--primary)' : 'var(--muted-foreground)' }} />
  if (id === 'swipe') return <SwipeIcon size={size} active={active} />
  if (id === 'peach') return <TrendingUp size={size} strokeWidth={active ? 2.5 : 1.8} style={{ color: active ? 'var(--primary)' : 'var(--muted-foreground)' }} />
  if (id === 'leads') return <Layers size={size} strokeWidth={active ? 2.5 : 1.8} style={{ color: active ? 'var(--primary)' : 'var(--muted-foreground)' }} />
  return null
}

export function TabBar({ activeView, onNavigate }: TabBarProps) {
  return (
    <nav
      className="shrink-0 flex items-center bg-[var(--tab-bar-bg)] border-t border-border"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      aria-label="Navegacion principal"
    >
      {tabs.map((tab) => {
        const isActive = activeView === tab.id
        return (
          <button
            key={tab.id}
            onClick={() => onNavigate(tab.id)}
            className="flex-1 flex flex-col items-center gap-1 py-3 relative transition-colors"
            aria-label={tab.label}
            aria-current={isActive ? 'page' : undefined}
          >
            <TabIcon id={tab.id} active={isActive} />
            <span
              className="text-[10px] font-semibold transition-colors"
              style={{ color: isActive ? 'var(--primary)' : 'var(--muted-foreground)' }}
            >
              {tab.label}
            </span>
            {isActive && (
              <motion.div
                layoutId="tab-indicator"
                className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-primary"
                transition={{ type: 'spring', stiffness: 500, damping: 35 }}
              />
            )}
          </button>
        )
      })}
    </nav>
  )
}
