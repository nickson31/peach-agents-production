'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Folder,
  FolderOpen,
  Archive,
  ChevronRight,
  Users,
  MapPin,
  Pencil,
  Check,
  X,
  Inbox,
  Layers,
} from 'lucide-react'
import { useLeads, type LeadsFolder } from '@/lib/leads-context'
import type { Lead } from '@/lib/leads-data'

// ─────────────────────────────────────────────
// Avatar helpers
// ─────────────────────────────────────────────
const AVATAR_COLORS: [string, string][] = [
  ['#fde8ea', '#fd5564'],
  ['#e8f9f1', '#21c17a'],
  ['#e8f0fd', '#4a7cfc'],
  ['#fdf5e8', '#f5a623'],
  ['#f0e8fd', '#9b59b6'],
  ['#e8fdfc', '#1abc9c'],
  ['#fef3e2', '#e67e22'],
  ['#e3f2fd', '#2196f3'],
]
function getAvatarColors(rowId: number): [string, string] {
  return AVATAR_COLORS[rowId % AVATAR_COLORS.length]
}
function getInitials(name: string) {
  return name
    .split(' ')
    .slice(0, 2)
    .map((n) => n[0])
    .join('')
    .toUpperCase()
}

// ─────────────────────────────────────────────
// Lead row inside an open folder
// ─────────────────────────────────────────────
function LeadRow({ lead }: { lead: Lead }) {
  const [avatarBg, avatarFg] = getAvatarColors(lead.row_id)
  const q = lead.metricas_tarjeta.lead_quality_score
  const scoreColor = q >= 80 ? 'var(--score-high)' : q >= 60 ? 'var(--score-mid)' : 'var(--score-low)'
  const hasLocation = lead.ubicacion_tarjeta && lead.ubicacion_tarjeta.toLowerCase() !== 'empty'

  return (
    <div className="flex items-center gap-3 px-5 py-3 border-b border-border/50 last:border-0">
      <div
        className="w-10 h-10 rounded-full shrink-0 flex items-center justify-center text-xs font-extrabold"
        style={{ background: avatarBg, color: avatarFg }}
      >
        {getInitials(lead.nombre_completo)}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="text-sm font-bold text-foreground truncate">{lead.nombre_completo}</p>
          <span
            className="text-[9px] font-bold px-1.5 py-0.5 rounded-full text-white shrink-0"
            style={{ background: scoreColor }}
          >
            {q}
          </span>
        </div>
        <p className="text-xs text-muted-foreground truncate leading-tight mt-0.5">
          {lead.subtitulo_tarjeta}
        </p>
        {hasLocation && (
          <div className="flex items-center gap-1 mt-0.5">
            <MapPin size={9} className="text-muted-foreground shrink-0" />
            <span className="text-[10px] text-muted-foreground truncate">
              {lead.ubicacion_tarjeta}
            </span>
          </div>
        )}
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────
// Folder card
// ─────────────────────────────────────────────
function FolderCard({ folder }: { folder: LeadsFolder }) {
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState(false)
  const [editName, setEditName] = useState(folder.name)
  const { renameFolder } = useLeads()

  const isArchive = folder.id === 'archivados'
  const FolderIcon = isArchive ? Archive : open ? FolderOpen : Folder

  const handleRename = () => {
    if (editName.trim()) renameFolder(folder.id, editName.trim())
    setEditing(false)
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card rounded-2xl border border-border overflow-hidden"
    >
      {/* Folder header */}
      <div
        className="flex items-center gap-3 px-4 py-3.5 active:bg-secondary/50 transition-colors cursor-pointer"
        onClick={() => !editing && setOpen((v) => !v)}
      >
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
          style={{
            background: isArchive
              ? '#f0f0f3'
              : folder.isStatic
              ? '#e8f0fd'
              : '#e8f9f1',
          }}
        >
          <FolderIcon
            size={18}
            style={{
              color: isArchive
                ? 'var(--muted-foreground)'
                : folder.isStatic
                ? '#4a7cfc'
                : 'var(--like-color)',
            }}
          />
        </div>

        <div className="flex-1 min-w-0">
          {editing ? (
            <input
              autoFocus
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              onBlur={handleRename}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleRename()
                if (e.key === 'Escape') setEditing(false)
              }}
              className="text-sm font-bold text-foreground bg-transparent outline-none border-b border-primary w-full"
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <p className="text-sm font-bold text-foreground truncate">{folder.name}</p>
          )}
          <div className="flex items-center gap-1 mt-0.5">
            <Users size={10} className="text-muted-foreground shrink-0" />
            <span className="text-[11px] text-muted-foreground">
              {folder.leads.length} perfil{folder.leads.length !== 1 ? 'es' : ''}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {editing ? (
            <>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  handleRename()
                }}
                className="w-7 h-7 flex items-center justify-center rounded-full bg-accent/10"
              >
                <Check size={13} className="text-accent" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  setEditing(false)
                }}
                className="w-7 h-7 flex items-center justify-center rounded-full bg-secondary"
              >
                <X size={13} className="text-muted-foreground" />
              </button>
            </>
          ) : (
            <>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  setEditName(folder.name)
                  setEditing(true)
                }}
                className="w-7 h-7 flex items-center justify-center rounded-full bg-secondary opacity-60 active:opacity-100"
              >
                <Pencil size={12} className="text-muted-foreground" />
              </button>
              <ChevronRight
                size={16}
                className="text-muted-foreground transition-transform"
                style={{ transform: open ? 'rotate(90deg)' : 'rotate(0deg)' }}
              />
            </>
          )}
        </div>
      </div>

      {/* Leads inside folder */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="border-t border-border">
              {folder.leads.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 gap-2">
                  <Inbox size={22} className="text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">
                    {folder.id === 'leads'
                      ? 'Guarda perfiles desde Swipe'
                      : folder.id === 'archivados'
                      ? 'Los perfiles archivados apareceran aqui'
                      : 'Sin perfiles en esta carpeta'}
                  </p>
                </div>
              ) : (
                folder.leads.map((lead) => <LeadRow key={lead.row_id} lead={lead} />)
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

// ─────────────────────────────────────────────
// Main Leads screen
// ─────────────────────────────────────────────
export function LeadsList() {
  const { folders } = useLeads()
  const totalLeads = folders.reduce((acc, f) => acc + f.leads.length, 0)

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      {/* Header */}
      <div className="px-5 pt-5 pb-3 shrink-0">
        <div className="flex items-center gap-2 mb-1">
          <Layers size={18} className="text-primary" />
          <h1 className="text-2xl font-extrabold text-foreground tracking-tight">Leads</h1>
        </div>
        <p className="text-xs text-muted-foreground font-medium">
          {folders.length} carpeta{folders.length !== 1 ? 's' : ''} · {totalLeads} perfil
          {totalLeads !== 1 ? 'es' : ''} guardados
        </p>
      </div>

      <div className="mx-5 border-t border-border" />

      {/* Folder list */}
      <div className="flex-1 overflow-y-auto overscroll-contain px-4 py-4 space-y-3">
        {folders.map((folder) => (
          <FolderCard key={folder.id} folder={folder} />
        ))}

        <p className="text-center text-[10px] text-muted-foreground pt-2 pb-4 font-medium">
          Las carpetas creadas por el asistente apareceran aqui
        </p>
      </div>
    </div>
  )
}
