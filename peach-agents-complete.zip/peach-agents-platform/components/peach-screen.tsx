'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  TrendingUp,
  Bot,
  Clock,
  Globe,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Zap,
  BarChart2,
  Radio,
} from 'lucide-react'
import { REPORT_TYPE_LABELS, type Report, type ReportType } from '@/lib/peach-data'
import { useResearch } from '@/lib/research-context'

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────
const TYPE_COLORS: Record<ReportType, { bg: string; text: string; border: string }> = {
  pre_london: { bg: '#e8f0fd', text: '#4a7cfc', border: '#4a7cfc22' },
  pre_newyork: { bg: '#fdf5e8', text: '#f5a623', border: '#f5a62322' },
  daily: { bg: '#e8f9f1', text: '#21c17a', border: '#21c17a22' },
  weekly: { bg: '#f0e8fd', text: '#9b59b6', border: '#9b59b622' },
  night: { bg: '#f0f0f3', text: '#8888a0', border: '#8888a022' },
}

function formatTime(iso: string) {
  const d = new Date(iso)
  return d.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })
}
function formatDate(iso: string) {
  const d = new Date(iso)
  return d.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })
}

// ─────────────────────────────────────────────
// Markdown renderer (same as chat)
// ─────────────────────────────────────────────
function renderMarkdown(text: string) {
  return text.split('\n').map((line, i) => {
    const parts = line.split(/\*\*(.*?)\*\*/g)
    return (
      <span key={i}>
        {parts.map((part, j) =>
          j % 2 === 1 ? (
            <strong key={j} className="font-bold text-foreground">
              {part}
            </strong>
          ) : (
            <span key={j}>{part}</span>
          )
        )}
        {'\n'}
      </span>
    )
  })
}

// ─────────────────────────────────────────────
// Report message bubble
// ─────────────────────────────────────────────
function ReportMessage({ report }: { report: Report }) {
  const [expanded, setExpanded] = useState(false)
  const colors = TYPE_COLORS[report.type]
  const PREVIEW_LENGTH = 500

  const isLong = report.body.length > PREVIEW_LENGTH
  const bodyToShow = !expanded && isLong ? report.body.slice(0, PREVIEW_LENGTH) + '...' : report.body

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col gap-2"
    >
      {/* Timestamp */}
      <div className="flex items-center gap-1.5 px-1">
        <Clock size={10} className="text-muted-foreground" />
        <span className="text-[10px] text-muted-foreground font-medium">
          {formatDate(report.createdAt)} · {formatTime(report.createdAt)}
        </span>
      </div>

      {/* Card */}
      <div
        className="rounded-2xl border overflow-hidden"
        style={{ background: '#ffffff', borderColor: colors.border }}
      >
        {/* Card header */}
        <div className="px-4 pt-4 pb-3 border-b border-border/40">
          <div className="flex items-start justify-between gap-2 mb-2">
            <div
              className="text-[10px] font-bold px-2.5 py-1 rounded-full"
              style={{ background: colors.bg, color: colors.text }}
            >
              {REPORT_TYPE_LABELS[report.type]}
            </div>
            {report.priority === 'high' && (
              <div className="flex items-center gap-1 text-[9px] font-bold text-[var(--nope-color)] bg-[#fde8ea] px-2 py-0.5 rounded-full">
                <Zap size={9} />
                HIGH
              </div>
            )}
          </div>
          <h3 className="text-sm font-extrabold text-foreground leading-tight">{report.title}</h3>

          {/* Assets */}
          <div className="flex flex-wrap gap-1.5 mt-2">
            {report.assetsFocus.map((a) => (
              <span
                key={a}
                className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-secondary text-muted-foreground"
              >
                {a}
              </span>
            ))}
          </div>
        </div>

        {/* Body */}
        <div className="px-4 py-3">
          <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">
            {renderMarkdown(bodyToShow)}
          </p>

          {isLong && (
            <button
              onClick={() => setExpanded((v) => !v)}
              className="flex items-center gap-1 mt-3 text-xs font-semibold text-primary"
            >
              {expanded ? (
                <>
                  <ChevronUp size={13} /> Mostrar menos
                </>
              ) : (
                <>
                  <ChevronDown size={13} /> Leer reporte completo
                </>
              )}
            </button>
          )}
        </div>

        {/* Sources */}
        {report.sources.length > 0 && (
          <div className="px-4 pb-4">
            <p className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground mb-2">
              Fuentes
            </p>
            <div className="flex flex-wrap gap-1.5">
              {report.sources.map((s) => (
                <a
                  key={s.name}
                  href={s.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-[10px] font-semibold px-2.5 py-1 rounded-full bg-secondary text-muted-foreground"
                >
                  <ExternalLink size={9} />
                  {s.name}
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  )
}

// ─────────────────────────────────────────────
// Research tab
// ─────────────────────────────────────────────
function ResearchView() {
  const { reports: contextReports } = useResearch()
  // Sort by newest first
  const reports = [...contextReports].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  )

  if (reports.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-5 px-6 pb-8">
        <div className="w-16 h-16 rounded-3xl bg-secondary flex items-center justify-center">
          <Radio size={28} className="text-muted-foreground" />
        </div>
        <div className="text-center">
          <p className="font-extrabold text-foreground text-lg">Sin reportes todavia</p>
          <p className="text-sm text-muted-foreground mt-2 leading-relaxed max-w-[280px]">
            Los reportes automaticos apareceran aqui cuando el motor de research empiece a ejecutarse.
          </p>
        </div>
        <div className="w-full space-y-2">
          {(['Daily Macro Brief', 'Pre-London Brief', 'Pre-New York Brief', 'Weekly Macro', 'Night Wrap'] as const).map((t) => (
            <div
              key={t}
              className="flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary border border-border"
            >
              <BarChart2 size={14} className="text-muted-foreground shrink-0" />
              <span className="text-sm text-muted-foreground font-medium">{t}</span>
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-y-auto overscroll-contain px-4 py-4 space-y-5">
      {reports.map((r) => (
        <ReportMessage key={r.id} report={r} />
      ))}
      <div className="h-4" />
    </div>
  )
}

// ─────────────────────────────────────────────
// Assistant tab (placeholder)
// ─────────────────────────────────────────────
function AssistantView() {
  return (
    <div className="flex flex-col items-center justify-center h-full gap-5 px-6 pb-8">
      <div className="w-16 h-16 rounded-3xl bg-secondary flex items-center justify-center">
        <Bot size={28} className="text-muted-foreground" />
      </div>
      <div className="text-center">
        <p className="font-extrabold text-foreground text-xl">Trading Assistant</p>
        <p className="text-sm text-muted-foreground mt-3 leading-relaxed max-w-[280px]">
          Pronto podras conectar tus indicadores, senales y preferencias de trading.
        </p>
        <p className="text-sm text-muted-foreground mt-2 leading-relaxed max-w-[280px]">
          El asistente generara alertas personalizadas e insights de mercado adaptados a tu estrategia.
        </p>
      </div>
      <div className="w-full space-y-2.5 mt-2">
        {[
          { icon: TrendingUp, label: 'Conectar indicadores personales' },
          { icon: Zap, label: 'Activar senales de trading' },
          { icon: Globe, label: 'Configurar alertas de mercado' },
          { icon: BarChart2, label: 'Definir activos prioritarios' },
        ].map(({ icon: Icon, label }) => (
          <div
            key={label}
            className="flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary border border-border opacity-60"
          >
            <Icon size={15} className="text-muted-foreground shrink-0" />
            <span className="text-sm text-muted-foreground font-medium">{label}</span>
          </div>
        ))}
      </div>
      <p className="text-[10px] text-muted-foreground font-medium text-center">
        Disponible en una proxima version
      </p>
    </div>
  )
}

// ─────────────────────────────────────────────
// Peach screen
// ─────────────────────────────────────────────
type PeachTab = 'research' | 'assistant'

export function PeachScreen() {
  const [tab, setTab] = useState<PeachTab>('research')

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      {/* Header */}
      <div className="px-5 pt-5 pb-3 shrink-0">
        <div className="flex items-center gap-2 mb-1">
          <TrendingUp size={18} className="text-primary" />
          <h1 className="text-2xl font-extrabold text-foreground tracking-tight">Peach</h1>
        </div>
        <p className="text-xs text-muted-foreground font-medium">Research y analisis de trading</p>
      </div>

      {/* Tab switcher */}
      <div className="mx-5 mb-3 flex gap-1 bg-secondary p-1 rounded-xl shrink-0">
        {(['research', 'assistant'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="flex-1 py-2 rounded-lg text-xs font-bold transition-all"
            style={{
              background: tab === t ? '#ffffff' : 'transparent',
              color: tab === t ? 'var(--foreground)' : 'var(--muted-foreground)',
              boxShadow: tab === t ? '0 1px 4px rgba(0,0,0,0.08)' : 'none',
            }}
          >
            {t === 'research' ? 'Research' : 'Assistant'}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        {tab === 'research' ? <ResearchView /> : <AssistantView />}
      </div>
    </div>
  )
}
