'use client'

import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, Square, Trash2, Sparkles, FolderPlus, Globe, Settings } from 'lucide-react'
import { useLeadsAssistant, type BraveResult } from '@/hooks/use-leads-assistant'
import { useLeads } from '@/lib/leads-context'
import { LEADS } from '@/lib/leads-data'
import { getStoredKeys } from '@/components/keys-setup'
import { useResearch, createReportFromWebSearch } from '@/lib/research-context'

const QUICK_PROMPTS = [
  'Muéstrame los mejores perfiles por lead quality',
  'Leads de Barcelona con alto capital',
  'Founders o Advisors con conocimiento crypto',
  'Agrupa los top inversores en una carpeta',
  '/web crypto Spain investor 2025',
]

function renderMarkdown(text: string) {
  // Simple inline markdown: **bold**, line breaks, numbered lists
  return text
    .split('\n')
    .map((line, i) => {
      const parts = line.split(/\*\*(.*?)\*\*/g)
      return (
        <span key={i}>
          {parts.map((part, j) =>
            j % 2 === 1 ? (
              <strong key={j} className="font-bold text-foreground">
                {part}
              </strong>
            ) : (
              <span key={j}>{part}</span>
            )
          )}
          {i < text.split('\n').length - 1 && <br />}
        </span>
      )
    })
}

export function ChatInterface({ onOpenSettings }: { onOpenSettings?: () => void }) {
  const [input, setInput] = useState('')
  const { createFolder } = useLeads()
  const { addReport } = useResearch()
  const { messages, isLoading, sendMessage, clearMessages, stopGeneration } =
    useLeadsAssistant()
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isLoading])

  const handleSend = (text?: string) => {
    const msg = (text ?? input).trim()
    if (!msg || isLoading) return
    const { braveQuery } = getStoredKeys()
    sendMessage(
      msg,
      LEADS,
      (folderName, leads) => createFolder(folderName, leads),
      braveQuery || undefined,
      (query: string, summary: string, sources: BraveResult[]) => {
        const report = createReportFromWebSearch(query, summary, sources)
        addReport(report)
      }
    )
    setInput('')
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value)
    e.target.style.height = 'auto'
    e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`
  }

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-5 pt-5 pb-3 shrink-0">
        <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0">
          <Sparkles size={18} className="text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-lg font-extrabold text-foreground leading-tight">Chat</h1>
          <p className="text-xs text-muted-foreground">
            {LEADS.length} perfiles en dataset
          </p>
        </div>
        <button
          onClick={clearMessages}
          className="w-9 h-9 flex items-center justify-center rounded-full bg-secondary border border-border active:bg-muted transition-colors"
          aria-label="Limpiar conversacion"
        >
          <Trash2 size={14} className="text-muted-foreground" />
        </button>
        {onOpenSettings && (
          <button
            onClick={onOpenSettings}
            className="w-9 h-9 flex items-center justify-center rounded-full bg-secondary border border-border active:bg-muted transition-colors"
            aria-label="Ajustes de API"
          >
            <Settings size={14} className="text-muted-foreground" />
          </button>
        )}
      </div>

      <div className="mx-5 border-t border-border" />

      {/* Messages */}
      <div className="flex-1 overflow-y-auto overscroll-contain px-4 py-3 space-y-4">
        {messages.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center gap-5 pt-4 pb-8"
          >
            <div className="w-16 h-16 rounded-3xl bg-primary/10 flex items-center justify-center">
              <Sparkles size={28} className="text-primary" />
            </div>
            <div className="text-center">
              <p className="font-extrabold text-foreground text-xl">Asistente de Leads</p>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed max-w-[280px]">
                Puedo buscar perfiles por ciudad, experiencia, industria o metricas, y crear carpetas
                automaticamente en Leads.
              </p>
            </div>

            <div className="w-full space-y-2">
              {QUICK_PROMPTS.map((prompt) => (
                <button
                  key={prompt}
                  onClick={() => handleSend(prompt)}
                  className="w-full text-left px-4 py-3 rounded-2xl bg-secondary text-sm text-secondary-foreground font-medium border border-border active:bg-muted transition-colors"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </motion.div>
        )}

        <AnimatePresence initial={false}>
          {messages.map((msg, i) => {
            const isUser = msg.role === 'user'
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.18 }}
                className={`flex ${isUser ? 'justify-end' : 'justify-start'} items-end gap-2`}
              >
                {!isUser && (
                  <div className="w-7 h-7 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 mb-0.5">
                    <Sparkles size={13} className="text-primary" />
                  </div>
                )}
                <div className="max-w-[85%] space-y-2">
                  <div
                    className="px-4 py-2.5 rounded-2xl"
                    style={
                      isUser
                        ? {
                            background: 'var(--primary)',
                            borderBottomRightRadius: '6px',
                          }
                        : {
                            background: '#ffffff',
                            border: '1px solid var(--border)',
                            borderBottomLeftRadius: '6px',
                          }
                    }
                  >
                    <p
                      className="text-sm leading-relaxed"
                      style={{ color: isUser ? '#fff' : 'var(--foreground)' }}
                    >
                      {isUser ? msg.content : renderMarkdown(msg.content)}
                    </p>
                  </div>

                  {/* Folder action badge */}
                  {!isUser && msg.action?.type === 'create_folder' && (
                    <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-accent/10 border border-accent/20">
                      <FolderPlus size={14} className="text-accent shrink-0" />
                      <p className="text-xs font-semibold text-accent">
                        Carpeta "{msg.action.folderName}" creada con {msg.action.leads.length} perfiles
                      </p>
                    </div>
                  )}

                  {/* Web results from Brave Search */}
                  {!isUser && msg.webResults && msg.webResults.length > 0 && (
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-1.5 px-1">
                        <Globe size={11} className="text-muted-foreground" />
                        <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                          Resultados web
                        </span>
                      </div>
                      {msg.webResults.map((r, ri) => (
                        <a
                          key={ri}
                          href={r.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block px-3 py-2 rounded-xl bg-secondary border border-border active:bg-muted transition-colors"
                        >
                          <p className="text-xs font-semibold text-foreground line-clamp-1">{r.title}</p>
                          <p className="text-[10px] text-muted-foreground mt-0.5 line-clamp-2 leading-snug">{r.description}</p>
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )
          })}
        </AnimatePresence>

        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-end gap-2"
          >
            <div className="w-7 h-7 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Sparkles size={13} className="text-primary" />
            </div>
            <div className="bg-white border border-border rounded-2xl rounded-bl-md px-4 py-3">
              <div className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-1.5 h-1.5 rounded-full bg-muted-foreground"
                    animate={{ y: [0, -4, 0] }}
                    transition={{ duration: 0.7, repeat: Infinity, delay: i * 0.15 }}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="shrink-0 bg-background border-t border-border px-4 py-3">
        <div className="flex items-end gap-2 bg-secondary rounded-2xl px-4 py-3 focus-within:ring-2 focus-within:ring-primary/20 transition-all">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            placeholder="Pregunta sobre leads..."
            rows={1}
            className="flex-1 bg-transparent text-sm text-foreground placeholder-muted-foreground resize-none outline-none leading-relaxed min-h-[22px] max-h-[120px]"
          />
          <button
            onClick={isLoading ? stopGeneration : () => handleSend()}
            disabled={!isLoading && !input.trim()}
            className="w-9 h-9 flex items-center justify-center rounded-full shrink-0 transition-all active:scale-90 disabled:opacity-40"
            style={{ background: isLoading ? '#fde8ea' : 'var(--primary)' }}
            aria-label={isLoading ? 'Detener' : 'Enviar'}
          >
            {isLoading ? (
              <Square size={12} className="text-[var(--nope-color)]" fill="var(--nope-color)" />
            ) : (
              <Send size={14} className="text-white" />
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
