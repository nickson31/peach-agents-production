'use client'

import { useRef, useState } from 'react'
import { motion, useMotionValue, useTransform, type PanInfo } from 'framer-motion'
import { MapPin, ChevronDown, ChevronUp, X, Heart, Briefcase, GraduationCap, Globe, Building2, Layers } from 'lucide-react'
import type { Lead } from '@/lib/leads-data'

interface LeadCardProps {
  lead: Lead
  onSwipe: (direction: 'left' | 'right', rowId: number) => void
  isTop: boolean
  stackIndex: number
}

const SWIPE_THRESHOLD = 80

// ── Avatar color palette ──────────────────────
const AVATAR_COLORS: [string, string][] = [
  ['#fde8ea', '#fd5564'],
  ['#e8f9f1', '#21c17a'],
  ['#e8f0fd', '#4a7cfc'],
  ['#fdf5e8', '#f5a623'],
  ['#f0e8fd', '#9b59b6'],
  ['#e8fdfc', '#1abc9c'],
  ['#fef3e2', '#e67e22'],
  ['#e3f2fd', '#2196f3'],
]
function getAvatarColors(rowId: number): [string, string] {
  return AVATAR_COLORS[rowId % AVATAR_COLORS.length]
}
function getInitials(name: string) {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0])
    .join('')
    .toUpperCase()
}

// ── Badge config ──────────────────────────────
type BadgeTier = 'elite' | 'high' | 'role' | 'trait' | 'default'

function getBadgeTier(label: string): BadgeTier {
  const l = label.toLowerCase()
  if (l.includes('élite') || l.includes('elite') || l.includes('dual')) return 'elite'
  if (l.includes('capital alto') || l.includes('crypto alto')) return 'high'
  if (l.includes('founder') || l.includes('investor') || l.includes('advisor')) return 'role'
  if (l.includes('senior') || l.includes('internacional') || l.includes('multilingüe') || l.includes('multilingue')) return 'trait'
  return 'default'
}

const BADGE_STYLES: Record<BadgeTier, { bg: string; color: string; border: string }> = {
  elite:   { bg: '#fff8e1', color: '#b8860b', border: '#f5d76e' },
  high:    { bg: '#e8f9f1', color: '#1a9e60', border: '#21c17a' },
  role:    { bg: '#e8f0fd', color: '#2d5fd4', border: '#7aadfc' },
  trait:   { bg: '#f0f0f3', color: '#555566', border: 'transparent' },
  default: { bg: '#f0f0f3', color: '#777788', border: 'transparent' },
}

function Badge({ label }: { label: string }) {
  const tier = getBadgeTier(label)
  const s = BADGE_STYLES[tier]
  return (
    <span
      className="text-[11px] font-semibold px-2.5 py-1 rounded-full border whitespace-nowrap"
      style={{ background: s.bg, color: s.color, borderColor: s.border }}
    >
      {label}
    </span>
  )
}

// ── Score bar ─────────────────────────────────
function ScoreBar({ label, score }: { label: string; score: number }) {
  const color =
    score >= 80 ? 'var(--score-high)' : score >= 60 ? 'var(--score-mid)' : 'var(--score-low)'
  return (
    <div className="flex items-center gap-2">
      <span className="text-[10px] font-semibold text-muted-foreground shrink-0 w-[72px]">{label}</span>
      <div className="flex-1 h-1.5 rounded-full bg-secondary overflow-hidden">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${Math.min(score, 100)}%`, background: color }}
        />
      </div>
      <span className="text-[10px] font-bold tabular-nums w-7 text-right shrink-0" style={{ color }}>
        {score}
      </span>
    </div>
  )
}

// ── Parse experience string: "Role en Company: description" ──
function parseExperience(raw: string): { role: string; company: string; desc: string } {
  // Pattern: "Role en Company: desc"  OR  "Role en Company"
  const enMatch = raw.match(/^(.+?)\s+en\s+([^:]+?)(?::\s*(.+))?$/)
  if (enMatch) {
    return {
      role: enMatch[1].trim(),
      company: enMatch[2].trim(),
      desc: enMatch[3]?.trim() ?? '',
    }
  }
  return { role: raw, company: '', desc: '' }
}

// ── Parse language string: "Español (Native or bilingual)" → "Español" ──
function parseLanguage(raw: string): { lang: string; level: string } {
  const match = raw.match(/^(.+?)\s*\((.+)\)$/)
  if (match) return { lang: match[1].trim(), level: match[2].trim() }
  return { lang: raw, level: '' }
}

// ── Main card ─────────────────────────────────
export function LeadCard({ lead, onSwipe, isTop, stackIndex }: LeadCardProps) {
  const x = useMotionValue(0)
  const rotate = useTransform(x, [-220, 220], [-14, 14])
  const likeOpacity = useTransform(x, [20, SWIPE_THRESHOLD], [0, 1])
  const nopeOpacity = useTransform(x, [-SWIPE_THRESHOLD, -20], [1, 0])
  const isDragging = useRef(false)
  const [expanded, setExpanded] = useState(false)

  const [avatarBg, avatarAccent] = getAvatarColors(lead.row_id)
  const { metricas_tarjeta: m } = lead
  const hasLocation = lead.ubicacion_tarjeta && lead.ubicacion_tarjeta.toLowerCase() !== 'empty'

  // Top 4 badges — skip "Ajuste dual élite" if space is needed, prioritise role/tier badges
  const displayBadges = lead.badges_tarjeta.slice(0, 5)

  // De-duplicate highlights against summary to avoid repetition
  const highlights = lead.highlights_tarjeta.slice(0, 4)

  const handleDragStart = () => { isDragging.current = true }
  const handleDragEnd = (_: unknown, info: PanInfo) => {
    isDragging.current = false
    if (info.offset.x > SWIPE_THRESHOLD) onSwipe('right', lead.row_id)
    else if (info.offset.x < -SWIPE_THRESHOLD) onSwipe('left', lead.row_id)
  }

  // Background card (stack preview)
  if (!isTop) {
    return (
      <div
        className="absolute inset-0 rounded-3xl bg-card border border-border"
        style={{
          transform: `translateY(${stackIndex * 12}px) scale(${1 - stackIndex * 0.04})`,
          opacity: Math.max(0, 1 - stackIndex * 0.25),
          zIndex: 10 - stackIndex,
        }}
      />
    )
  }

  return (
    <motion.div
      className="absolute inset-0 rounded-3xl bg-card shadow-xl border border-border overflow-hidden select-none"
      style={{ x, rotate, zIndex: 20, touchAction: 'pan-y' }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={0.5}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      {/* LEAD stamp */}
      <motion.div
        className="absolute top-8 left-6 z-30 border-[3px] border-[var(--like-color)] rounded-2xl px-3 py-1 -rotate-12 pointer-events-none"
        style={{ opacity: likeOpacity }}
      >
        <span className="text-[var(--like-color)] font-extrabold text-xl tracking-widest">LEAD</span>
      </motion.div>

      {/* SKIP stamp */}
      <motion.div
        className="absolute top-8 right-6 z-30 border-[3px] border-[var(--nope-color)] rounded-2xl px-3 py-1 rotate-12 pointer-events-none"
        style={{ opacity: nopeOpacity }}
      >
        <span className="text-[var(--nope-color)] font-extrabold text-xl tracking-widest">SKIP</span>
      </motion.div>

      <div
        className="h-full overflow-y-auto overscroll-contain"
        style={{ WebkitOverflowScrolling: 'touch', touchAction: 'pan-y' }}
      >
        {/* ── HEADER ── */}
        <div
          className="flex flex-col items-center justify-center gap-3 pt-10 pb-6 px-6 relative"
          style={{ background: avatarBg }}
        >
          {/* Quality badge */}
          <div
            className="absolute top-4 right-4 flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold text-white z-10"
            style={{
              background:
                m.lead_quality_score >= 90 ? '#21c17a'
                : m.lead_quality_score >= 70 ? '#f5a623'
                : '#aaaabc',
            }}
          >
            <span>{m.lead_quality_score}</span>
            <span className="text-white/80 font-medium">pts</span>
          </div>

          {/* Dual score badge top-left */}
          {m.priority_dual_score > 0 && (
            <div
              className="absolute top-4 left-4 flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold z-10"
              style={{ background: '#fff8e1', color: '#b8860b', border: '1px solid #f5d76e' }}
            >
              <span>#{Math.round(m.priority_dual_score)}</span>
            </div>
          )}

          <div
            className="w-24 h-24 rounded-full flex items-center justify-center text-3xl font-extrabold shadow-md"
            style={{ background: avatarAccent, color: '#fff' }}
          >
            {getInitials(lead.nombre_completo)}
          </div>

          <div className="text-center px-2">
            <h2 className="text-2xl font-extrabold text-foreground leading-tight text-balance">
              {lead.nombre_completo}
            </h2>
            {lead.subtitulo_tarjeta && (
              <p className="text-sm font-medium text-secondary-foreground mt-1 leading-snug line-clamp-2">
                {lead.subtitulo_tarjeta}
              </p>
            )}
          </div>

          {hasLocation && (
            <div className="flex items-center gap-1.5 bg-white/70 backdrop-blur-sm px-3 py-1.5 rounded-full">
              <MapPin size={11} className="text-muted-foreground shrink-0" />
              <span className="text-xs font-semibold text-foreground">{lead.ubicacion_tarjeta}</span>
            </div>
          )}
        </div>

        {/* ── BADGES ── */}
        {displayBadges.length > 0 && (
          <div className="px-5 pt-4 pb-2 flex flex-wrap gap-1.5">
            {displayBadges.map((b) => <Badge key={b} label={b} />)}
          </div>
        )}

        {/* ── RESUMEN ── */}
        <div className="px-5 pt-3 pb-4">
          <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">Perfil</p>
          <p className="text-sm text-secondary-foreground leading-relaxed">{lead.resumen_tarjeta}</p>
        </div>

        {/* ── HIGHLIGHTS ── */}
        {highlights.length > 0 && (
          <div className="px-5 pb-4">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">Highlights</p>
            <div className="space-y-1.5">
              {highlights.map((h, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span
                    className="w-1.5 h-1.5 rounded-full shrink-0 mt-[6px]"
                    style={{ background: 'var(--like-color)' }}
                  />
                  <p className="text-sm text-foreground leading-snug">{h}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── SCORES ── */}
        <div className="mx-5 mb-4 p-3.5 rounded-2xl bg-secondary/60">
          <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-3">Métricas</p>
          <div className="space-y-2.5">
            <ScoreBar label="Lead quality" score={m.lead_quality_score} />
            <ScoreBar label="Capital" score={m.capital_score} />
            <ScoreBar label="Crypto" score={m.crypto_score} />
          </div>
        </div>

        {/* ── EXPANDIBLE ── */}
        <div className="px-5 pb-2">
          <button
            onClick={(e) => { e.stopPropagation(); setExpanded((v) => !v) }}
            className="w-full flex items-center justify-between py-2.5 text-xs font-bold uppercase tracking-wider text-muted-foreground border-t border-border"
          >
            <span>Ver más detalles</span>
            {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>
        </div>

        {expanded && (
          <div className="px-5 pb-4 space-y-5">
            {/* Areas */}
            {lead.detalle_expandible.areas.length > 0 && (
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <Layers size={12} className="text-muted-foreground" />
                  <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Áreas</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {lead.detalle_expandible.areas.map((a) => (
                    <span
                      key={a}
                      className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground"
                    >
                      {a}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Experiencia */}
            {lead.detalle_expandible.experiencia.length > 0 && (
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <Briefcase size={12} className="text-muted-foreground" />
                  <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Experiencia</p>
                </div>
                <div className="space-y-2.5">
                  {lead.detalle_expandible.experiencia.slice(0, 3).map((e, i) => {
                    const { role, company, desc } = parseExperience(e)
                    return (
                      <div key={i} className="pl-2 border-l-2 border-border">
                        <p className="text-sm font-semibold text-foreground leading-snug">{role}</p>
                        {company && (
                          <p className="text-xs text-muted-foreground mt-0.5">{company}</p>
                        )}
                        {desc && (
                          <p className="text-xs text-secondary-foreground mt-0.5 leading-snug line-clamp-2">{desc}</p>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Educacion */}
            {lead.detalle_expandible.educacion.length > 0 && (
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <GraduationCap size={12} className="text-muted-foreground" />
                  <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Educación</p>
                </div>
                <div className="space-y-1.5">
                  {lead.detalle_expandible.educacion.map((ed, i) => {
                    // "Grado X en Universidad Y" → split at last " en "
                    const enIdx = ed.lastIndexOf(' en ')
                    const degree = enIdx > 0 ? ed.slice(0, enIdx).trim() : ed
                    const school = enIdx > 0 ? ed.slice(enIdx + 4).trim() : ''
                    return (
                      <div key={i} className="pl-2 border-l-2 border-border">
                        <p className="text-sm font-semibold text-foreground leading-snug">{degree}</p>
                        {school && <p className="text-xs text-muted-foreground mt-0.5">{school}</p>}
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Idiomas */}
            {lead.detalle_expandible.idiomas.length > 0 && (
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <Globe size={12} className="text-muted-foreground" />
                  <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Idiomas</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {lead.detalle_expandible.idiomas.map((l) => {
                    const { lang, level } = parseLanguage(l)
                    const isNative = level.toLowerCase().includes('native') || level.toLowerCase().includes('nativo') || level.toLowerCase().includes('bilingual')
                    return (
                      <span
                        key={l}
                        className="text-[11px] font-semibold px-2.5 py-1 rounded-full border"
                        style={{
                          background: isNative ? '#e8f0fd' : '#f0f0f3',
                          color: isNative ? '#2d5fd4' : '#555566',
                          borderColor: isNative ? '#7aadfc' : 'transparent',
                        }}
                        title={level || undefined}
                      >
                        {lang}
                      </span>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Industrias */}
            {lead.detalle_expandible.industrias.length > 0 && (
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <Building2 size={12} className="text-muted-foreground" />
                  <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Industrias</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {lead.detalle_expandible.industrias.map((ind) => (
                    <span
                      key={ind}
                      className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground"
                    >
                      {ind}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── ACTION BUTTONS ── */}
        <div className="px-5 pb-8 pt-4">
          <div className="flex items-center justify-center gap-6">
            <button
              onClick={(e) => { e.stopPropagation(); onSwipe('left', lead.row_id) }}
              className="w-16 h-16 rounded-full bg-white shadow-md border border-border flex items-center justify-center active:scale-90 transition-transform"
              aria-label="Archivar lead"
            >
              <X size={26} className="text-[var(--nope-color)]" strokeWidth={2.5} />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onSwipe('right', lead.row_id) }}
              className="w-20 h-20 rounded-full shadow-lg flex items-center justify-center active:scale-90 transition-transform"
              style={{ background: 'var(--like-color)' }}
              aria-label="Guardar lead"
            >
              <Heart size={32} className="fill-white text-white" />
            </button>
          </div>
          <p className="text-center text-[10px] text-muted-foreground mt-4 font-medium">
            desliza o usa los botones
          </p>
        </div>
      </div>
    </motion.div>
  )
}
