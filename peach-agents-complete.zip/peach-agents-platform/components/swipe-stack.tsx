'use client'

import { useState, useCallback, useEffect } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Inbox, Heart, X } from 'lucide-react'
import { LeadCard } from '@/components/lead-card'
import { useLeads } from '@/lib/leads-context'
import type { Lead } from '@/lib/leads-data'

interface SwipeStackProps {
  leads: Lead[]
}

export function SwipeStack({ leads }: SwipeStackProps) {
  const { addLeadToFolder } = useLeads()
  const [queue, setQueue] = useState<Lead[]>(leads)
  const [lastAction, setLastAction] = useState<'like' | 'dislike' | null>(null)

  useEffect(() => {
    setQueue(leads)
  }, [leads.length]) // eslint-disable-line react-hooks/exhaustive-deps

  const handleSwipe = useCallback(
    (direction: 'left' | 'right', rowId: number) => {
      const lead = queue.find((l) => l.row_id === rowId)
      if (!lead) return
      if (direction === 'right') {
        addLeadToFolder('leads', lead)
        setLastAction('like')
      } else {
        addLeadToFolder('archivados', lead)
        setLastAction('dislike')
      }
      setQueue((prev) => prev.filter((l) => l.row_id !== rowId))
      setTimeout(() => setLastAction(null), 700)
    },
    [queue, addLeadToFolder]
  )

  const topLead = queue[0]
  const previewLeads = queue.slice(1, 3)

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-5 pb-2 shrink-0">
        <div>
          <h1 className="text-2xl font-extrabold text-foreground tracking-tight">Swipe</h1>
          <p className="text-xs text-muted-foreground font-medium mt-0.5">
            {queue.length} perfil{queue.length !== 1 ? 'es' : ''} pendiente
            {queue.length !== 1 ? 's' : ''}
          </p>
        </div>

        <AnimatePresence mode="wait">
          {lastAction ? (
            <motion.div
              key={lastAction}
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.6 }}
              transition={{ duration: 0.15 }}
              className="w-11 h-11 rounded-full flex items-center justify-center shadow"
              style={{
                background: lastAction === 'like' ? '#e8f9f1' : '#fde8ea',
              }}
            >
              {lastAction === 'like' ? (
                <Heart size={20} className="fill-[var(--like-color)] text-[var(--like-color)]" />
              ) : (
                <X size={20} className="text-[var(--nope-color)]" strokeWidth={2.5} />
              )}
            </motion.div>
          ) : (
            <div key="empty" className="w-11 h-11" />
          )}
        </AnimatePresence>
      </div>

      {/* Card stack area */}
      <div className="flex-1 relative mx-4 mt-1 mb-2 min-h-0">
        {queue.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute inset-0 flex flex-col items-center justify-center gap-4"
          >
            <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center">
              <Inbox size={32} className="text-muted-foreground" />
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-foreground">Todo al dia</p>
              <p className="text-sm text-muted-foreground mt-1">
                No quedan perfiles por revisar
              </p>
            </div>
          </motion.div>
        ) : (
          <>
            {previewLeads.map((lead, i) => (
              <LeadCard
                key={lead.row_id}
                lead={lead}
                onSwipe={handleSwipe}
                isTop={false}
                stackIndex={i + 1}
              />
            ))}

            <AnimatePresence>
              {topLead && (
                <motion.div
                  key={topLead.row_id}
                  className="absolute inset-0"
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.18 }}
                >
                  <LeadCard
                    lead={topLead}
                    onSwipe={handleSwipe}
                    isTop={true}
                    stackIndex={0}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </>
        )}
      </div>
    </div>
  )
}
